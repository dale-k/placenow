<?php

namespace App;

use DB;
use Illuminate\Database\Eloquent\Model;

class Place extends Model
{
	
    public function picture(){
    	return $this->hasMany(Picture::class);
    }

    public function picturebydate($num){
        return $this->hasMany(Picture::class)->orderBy('created_at','desc')->take($num)->get();
    }

    public function picturebypopluar($num){
        return $this->hasMany(Picture::class)
        ->select(DB::raw('pictures.* , (pictures.vote_count+pictures.favor_count+pictures.recommend_count+pictures.view_count) as count '))
        ->orderBy('count','desc')->take($num)->get();
    }


    public function picture_ByCity($place){
    	$result = [];
    	$result = $this
                    ->join('pictures','places.id','=','pictures.place_id')
                    ->select('pictures.*','places.*')
                    ->where('places.city','=',$place)
                    ->get();
        if (count($result)){
    		return $result;
    	}else{
    		return $result;
    	}
    }
 

	 
}

