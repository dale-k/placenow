<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;


class Tag extends Model
{
    public function TopPicture($type){
       $picture = Picture::join('tags','pictures.id','=','tags.picture_id')
                       ->select(DB::raw('pictures.* ,(pictures.vote_count + pictures.favor_count + pictures.recommend_count + pictures.view_count) as sum'))
                       ->where('tags.type',$type)
                       ->orderBy('sum','desc')
                       ->first();
        return $picture;
    }
    public function storeNewTag($picture_id,$string){
        // do all the protection  , trim / take out additonal white space / change all to lowercase
        // $string = strtolower($string);
        $string = str_replace("   "," ",$string);
        $string = str_replace("  "," ",$string);
        $string = trim($string);

        

        if ( $string != '' ){

            $tags = explode(" ",$string);

            foreach($tags as $tag){
                $store = new Tag;
                $store->type =substr($tag,1);
                $store->picture_id = $picture_id;
                $store->save();
            }
        }

    }
    public function loadTopPicturefromtype(){
       return $this->hasMany(Picture::class)->select(DB::raw('pictures.* ,(pictures.vote_count + pictures.favor_count + pictures.recommend_count + pictures.view_count) as sum'))
                    ->orderBy('sum','desc')
                    ->first();
    }
    public function loadPicturefromtype($type){
        $pictures = Picture::join('tags','pictures.id','=','tags.picture_id')
                       ->select('pictures.*')
                       ->where('tags.type',$type)
                       ->orderBy('created_at','desc')
                       ->take(12)
                       ->get();
    
        return $pictures;
    
    }
    public function getTagsRelated($type){
        $pictures = $this->where('type','like','%'.$type.'%')->get();

    }
    public function getTagsOnCount($num){
        $tags = $this->join('pictures','tags.picture_id','=','pictures.id')
                     ->select(DB::raw('tags.* , pictures.pic_location,(pictures.vote_count + pictures.favor_count + pictures.recommend_count + pictures.view_count) as sum,COUNT(tags.type) as count'))
                     ->orderBy('sum','desc')
                     ->groupby('type')
                     ->orderBy('count','desc')
                     ->take($num)
                     ->get();
        return $tags;
    }

    public function loadAlltags($picture_id){
        $tags = $this->where('picture_id',$picture_id)->get();
        
        return $tags;
    
    }
    
    public function countThisTag($type){

        return $this->where('type',$type)->count();
    }

}
 