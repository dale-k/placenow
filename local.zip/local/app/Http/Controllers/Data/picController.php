<?php

namespace App\Http\Controllers\Data;

use Illuminate\Http\Request;

use App\Http\Requests;

class picController extends Controller
{
    //
    function uploadPhoto(){
    	
    }
}
