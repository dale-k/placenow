@extends('layouts.master')
@section('style')
{{-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/css/jasny-bootstrap.min.css"> --}}
<link rel="stylesheet" type="text/css" href="{{ URL::asset('css/uploadmyphoto.css') }}">
@endsection

@section('title','Place Now - Post')

@section('top')
@overwrite

@section('content')


	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 wrap-all" style="padding: 0;">
				<div class="wrap-nav">
					<div class="col-xs-2 wrap-go-back-btn" onclick="prevStep();">
						<span class="glyphicon glyphicon-chevron-left go-back-btn" aria-hidden="true"></span>
					</div>
					{{-- <div class="col-xs-9 nav-header" id="pageHeader1">
						<h1>Post My Photo</h1>
					</div> --}}
					<div class="col-xs-8 nav-header">
						Post My Photo
						{{-- <span class="glyphicon glyphicon-camera go-back-btn" aria-hidden="true"></span> --}}
					</div>
					<div class="col-xs-2">
						<span class="glyphicon glyphicon-align-justify go-back-btn" aria-hidden="true"></span>
					</div>
				</div>
				<div class="col-md-12">
					<div id="map"><!--<input type="hidden" id="hiddens" name="_token" value="{{ csrf_token() }}">--></div>
					<div class="panel">
						<div class="panel-heading">
							<h2 class="panel-title" id="panelTitle"></h2> 
							<p id="selected-place"></p>
							<a class="btn"id="refresh-list" onclick="initMap();"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span></a>
						</div>
						<div class="panel-body" id="panelBody"></div>
					</div>
				</div>
			</div>
			<div class="col-md-3"></div>
		</div>
		
		
	</div><!-- container -->

@endsection

@section('buttom')
@overwrite



@section('script')
@section('replace-google-map-api')

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDIgTQnz-ogU8mW_AidCUlYomtlrCDxUGQ&libraries=places&callback=initMap" async defer></script>

@overwrite

<script src="{{ URL::asset('js/uploadmyphoto.js') }}"></script>
{{-- <script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script> --}}
@endsection