<?php $__env->startSection('title','Tag - #'.$select_tag['tag']); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/tag.css')); ?>">
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.tag_navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">


	<div class="row wrap-content">
		
  	<div class="col-md-2" style="height:1px;"></div>
		<div class="col-md-8 wrap-image">
<?php $__env->startSection('load-image'); ?>
			<div class="row img-container grid">
      <div class="col-xs-4 col-sm-6 col-md-4 grid-sizer"></div>
			  <?php foreach( $tag_pictures as $tp ): ?>
        <div class="popular-img-wrap col-md-4 col-xs-4 grid-item">
          <span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;<?php echo e(trimCreatedAt($tp->created_at)); ?>

          <a href="<?php echo e(url('/photo/'.$tp->id)); ?>">
          <img class='img-responsive' alt="" src="<?php echo e(url($tp->pic_location)); ?>"></a>
          <div class="img-counts col-md-12 col-xs-12">
             <div class="col-md-3 col-xs-3 pic-counts"> <?php echo e($tp->vote_count); ?> <span class="glyphicon glyphicon-heart" aria-hidden="true"></span></div>
             <div class="col-md-3 col-xs-3 pic-counts"><?php echo e($tp->favor_count); ?><span class="glyphicon glyphicon-star" aria-hidden="true"></span></div>
             <div class="col-md-3 col-xs-3 pic-counts"> <?php echo e($tp->recommend_count); ?> <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span></div>
             <div class="col-md-3 col-xs-3 pic-counts"> <?php echo e($tp->view_count); ?> <span class="glyphicon glyphicon-play" aria-hidden="true"></span></div>
          </div>
            <div class="tag-list col-md-12 col-xs-12">
              <?php foreach($tp->tag as $tag): ?>
              <a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;
              <?php endforeach; ?>
            </div>
            
          </div>
		    <?php endforeach; ?>	
		    </div>
<?php echo $__env->yieldSection(); ?>
		</div>    
	</div>

</div>



<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/tag.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>