<?php $__env->startSection('title','Place Now - tagtest'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
    <style type="text/css">


/*tag*/
.row{
	margin-top: 5px;
}
.row-1{
  height:610px;
  margin-bottom:5px;
}
.box-wrap {
  padding:0px;
}
.big-img-wrap{
  padding-top:0px;
  padding-left: 0px;
  padding-bottom: 3px;
  padding-right:3px;
  overflow:hidden;
  height:303px;

}
.box-wrap > div{
  padding-top:0px;
  padding-left: 0px;
  padding-bottom: 3px;
  padding-right:3px;
  
}



.img-wrap a {
  position: relative;
  display:block;
  width:100%;
  height:150px !important;
  overflow: hidden;
}
.big-img-wrap a {
  position: relative;
  display:block;
  width:100%;
  height:303px !important;
  overflow: hidden;
}
.wrapped-img{
  position: relative;
}

.tag-overlay{
  position: absolute;
  bottom:0px;
  width:100%;
  height:30px;
  color: #333;
  background-color: #c3c3c3;
  z-index: 6;
  opacity: 0.5;
}
.tag-overlay>div{
  height: 30px;
  line-height: 30px;
  text-align: center;
  font-size: 20px;
  font-weight: 300;
  z-index: 10;
  color:black;
  opacity: 1;
}
.tag-move-up{
  
  float:left;
  z-index: 10;
}
hr{
  border-top: 1px solid #988e8e;
}
/*    Carousel      */
.carousel .item {
    /*height: 500px; OLD*/
    /*background-color: #777; OLD*/

    width:100%;
    height:inherit;
}
.carousel-inner > .item > img {
  /*position: absolute; OLD+WHY?*/
  /*top: 0; OLD+WHY?*/
  /*left: 0; OLD+WHY?*/

  min-width:100%;
  height:inherit;
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php foreach($tags as $tag): ?>
<?php echo e($tag->type."    ".$tag->count); ?>

<?php endforeach; ?>
<div class="container">
    <div class="tag_title"> <h1> most view </h1> </div>
 <hr class="divider">
 <div class="row row-1 ">

    <div class="big-img-wrap col-md-6 carousel-1 slide">
      <div class="carousel-inner" role="listbox">
      <a id="link" class="item active" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#pokemon</div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#pokemonGo</div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#pokemon_rare</div></div>
      </a>
      </div>
    </div>
    <div class="box-wrap col-md-6">
      <div class="img-wrap col-md-8 carousel-2 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#sport</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#baseball</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#football</div></div>
        </a>
        </div>
      </div>

  		<div class="img-wrap col-md-4 carousel-3 slide">
        <div class="carousel-inner" role="listbox">
  			<a id="link" class="item  active" href="#">
  			<img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
  			<div class="tag-overlay"><div>#food</div></div>
  			</a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#restaurant</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#delicious</div></div>
        </a>
        </div>
  		</div>
  		
  		<div class="img-wrap col-md-4 carousel-4 slide">
  		  <div class="carousel-inner" role="listbox">
      	<a id="link" class="item  active" href="#">
  			<img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
  			<div class="tag-overlay"><div>#fun</div></div>
  			</a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#funny</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#interesting</div></div>
        </a>
        </div>
  		</div>

  		<div class="img-wrap col-md-8 carousel-5 slide">
        <div class="carousel-inner" role="listbox">
  			<a id="link" class="item  active" href="#">
  			<img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
  			<div class="tag-overlay"><div>#love</div></div>
  			</a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#relationship</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#happiness</div></div>
        </a>
        </div>
  		</div>
    </div>
                <!-- next line -->
    <div class="box-wrap col-md-6">
  		<div class="img-wrap col-md-4 carousel-6 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#home</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#family</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#house</div></div>
        </a>
        </div>
  		</div>

  		<div class="img-wrap col-md-8 carousel-7 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#good</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#amazing</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#wonderful</div></div>
        </a>
        </div>
  		</div>

      <div class="img-wrap col-md-8 tag-move-up carousel-8 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#cool</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#dangerous</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#fake</div></div>
        </a>
        </div>
      </div>

      <div class="img-wrap col-md-4 tag-move-up carousel-9 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#newopening</div></div>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#closed</div></div>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#shutdown</div></div>
        </a>
        </div>
      </div>

    </div>

    <div class="big-img-wrap col-md-6 last-big-img carousel-10 slide">
      <div class="carousel-inner" role="listbox">
      <a id="link" class="item  active" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#other</div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#something</div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#somethingelse</div></div>
      </a>
      </div>
    </div>
    
  </div>

  <div class="row row-2">
  <div class="title-move-left">
  <h1>latest</h1>
  <hr class="divider">
  </div>
  </div>

	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/welcome.js')); ?>"></script>

<script>

$(document).ready(function(){

  
 $('.carousel-1').carousel({ interval: 10000});// big
 $('.carousel-2').carousel({ interval: 7000 });
 $('.carousel-3').carousel({ interval: 4500 });// small
 $('.carousel-4').carousel({ interval: 5500 });// small
 $('.carousel-5').carousel({ interval: 4500 });
 $('.carousel-6').carousel({ interval: 6500 });// small
 $('.carousel-7').carousel({ interval: 8000 });
 $('.carousel-8').carousel({ interval: 9000 });
 $('.carousel-9').carousel({ interval: 3500 });// small
 $('.carousel-10').carousel({ interval: 9500 }); // big

$("img").width( $("img").parent().width());
$("img").height("inherit");

});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>