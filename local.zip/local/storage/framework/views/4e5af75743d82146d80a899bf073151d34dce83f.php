<?php $__env->startSection('title','Place Now - welcome'); ?>

<?php $__env->startSection('style'); ?>
  <?php /* <link href='https://fonts.googleapis.com/css?family=PT+Sans:700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Berkshire+Swash' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Permanent+Marker' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Vollkorn' rel='stylesheet' type='text/css'> */ ?>
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/user.blade.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




<?php foreach( $pictures as $pic ): ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<a href="<?php echo e(url('/photo/'.$pic->id)); ?>" class="wrap-img">
				<img class="img-responsive" alt="" src="<?php echo e(url($pic->pic_location)); ?>">
				<div class="wrap-vote-count">
					<span class="glyphicon glyphicon-heart-empty" aria-hidden="true"></span>
					<?php echo e($pic->vote_count); ?>

				</div>
			</a>
			<div class="latest-info tag-color">
				<div class="wrap-latest-tags tag-color">
					<a class="">#<?php echo e($pic->place->location); ?></a>
					<?php foreach( $pic->tag as $tag ): ?>
					<a class="">#<?php echo e($tag->type); ?></a>
					<?php endforeach; ?>
				</div>
				<?php if($pic->title != ''): ?>
				<div class="latest-title"><h3><?php echo e($pic->title); ?></h3></div>
				<?php endif; ?>
				<div class="latest-comment"><p><?php echo e($pic->comment); ?></p></div>
			</div>
		</div>
	</div>
</div>

<?php endforeach; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>