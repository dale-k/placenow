<?php $__env->startSection('title','Place Now - welcome'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/test.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/welcom_carousel.css')); ?>">
    <style type="text/css">
      .content-top {
        padding-top: 10px;
        padding-bottom: 10px;
      }

      .glyphicon {
        top: 3px !important;
      }
      .share-photo {
        background-color: #c1253e;
      }
      .join-chat {

      }

      .grid:after {
        content: '';
        display: block;
        clear: both;
      }

      #dropdown-sort{
        margin-left:3px;
        margin-bottom:5px;
      }

      

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top'); ?>
<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="row top">
    <div class="col-md-12">
      <a class="brand" href="<?php echo e(url('/welcome')); ?>">What's Happening!</a>
    </div>
  </div>
  <div class="row wrap-nav-row">
    <div class="wrap-nav">
      <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url('/welcome')); ?>">World</a></li>
        <li role="presentation"><a href="#"><?php echo e($user_pos->city); ?></a></li>
        <li role="presentation"><a href="#">Nearby</a></li>
        <li role="presentation"><a href="<?php echo e(url('/tagtest')); ?>">Tags</a></li>
        <li>
          <a href="/placenow/postmyphoto" class="nav-share-photo" role="button">
            <!--<span class="glyphicon glyphicon-camera" aria-hidden="true"></span>-->
            SharePhoto
          </a>
        </li>
        <li>
          <a href="/placenow/chat" class="nav-join-chat" role="button">
            <?php /* <span class="glyphicon glyphicon-comment" aria-hidden="true"></span> */ ?>
            TalkToYourNeighbor
          </a>
        </li>
        <li role="presentation"><a href="#">Search</a></li>
        <li>
          <a href="#collapseAsk" class="nav-ask-collapse" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="collapseAsk">
            <?php /* <span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> */ ?>
            Ask
          </a>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
              Me<span class="caret"></span>
          </a>

          <ul class="dropdown-menu" role="menu">
              <li><a href=""><i class="fa fa-btn fa-sign-out"></i></a></li>
              <li><a href="<?php echo e(url('/profile')); ?>"><i class="fa fa-btn fa-sign-out"></i>Profile</a></li>
              <?php if(Auth::user()->email=='admin@admin.admin'): ?>
              <li><a href="<?php echo e(url('/management')); ?>"><i class="fa fa-btn fa-sign-out"></i>Management</a></li>
              <?php endif; ?> 
              <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
          </ul>
      </li>
      </ul>
    </div>
  </div>
</div>

<div class="container-fluid wrap-top-container">

<div class="container">
  

<!--
  <div class="row wrap-best padding-remove">
    <?php foreach( $best_place as $bp ): ?> 
    <div class="best-title col-md-12">
    </div>
    <div class="col-xs-12 col-sm-8 col-md-8 wrap-best wrap-margin">
      <a href="<?php echo e(url('/photo/'.Crypt::encrypt($bp->id))); ?>" class="wrap-best-img">
        <img class="img-responsive" alt="Responsive image" src="<?php echo e($bp->pic_location); ?>">
        <?php /* <?php echo e($pc['city']); ?> */ ?>
      </a>
      <div class="wrap-best-content">
        <div class="best-content-tag">
          <a>#whatshappening</a>
          <a>#Tucson</a>
          <a>#AZ</a>
        </div>
        <div class="best-content-title">
          <h2>Whatshappening Launched</h2>
        </div>
        <div class="best-content-comment">
          Whathappening was founded by two developer. This 
          <?php echo e($bp->comment); ?>

        </div>
        <div class="best-author">
          <a href="#" class="best-author-img">
            <img src="<?php echo e(url('/img/profile-image.jpg')); ?>" alt="" class="media-object img-circle uploader-profile-image">
          </a>
          <a class="best-author-name">By <?php echo e($bp->user->user); ?></a>
          <p class="best-posted-at">
            <?php if( (time()-strtotime($bp->created_at)) > 43200 ): ?>
              <?php echo e(date( "m-d-y", strtotime($bp->created_at) )); ?></p>
            <?php else: ?>
              <?php if( time()-strtotime($bp->created_at) < 60 ): ?>
                <?php echo e(strtotime($bp->created_at)); ?>s ago
              <?php elseif( time()-strtotime($bp->created_at) > 60 || time()-strtotime($bp->created_at) < 3600 ): ?>
                <?php echo e(round( strtotime($bp->created_at)/60 )); ?>m ago
              <?php elseif( time()-strtotime($bp->created_at) > 3600 ): ?>
                <?php echo e(round( strtotime($bp->created_at)/3600 )); ?>h ago
              <?php endif; ?>
            <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
-->
<div class="row padding-remove">
  <div class="wrap-margin">
    <div class="col-xs-12 col-sm-8 col-md-7 wrap-best">
      <!--<div class="best-title">It's Happening Now</div>-->
      <a href="http://localhost/placenow/photo/eyJpdiI6IlQ1N2lmZXhONjhJRGZmUXV2Z1ZVZ3c9PSIsInZhbHVlIjoiTHY3U29QWTlVQVJnd1ZxcFBYZU92UT09IiwibWFjIjoiMGJkZDFmMjIxN2VlODE1NmI4Y2ZlNGMzNTU2N2E1NWYyM2VjNDAzNmZkMmZiOGJkODE1OTRlNDY1OTNjN2FmZiJ9" class="wrap-best-img">
        <img class="img-responsive" alt="Responsive image" src="img/Tucson2016-06-29--04-54-40am.jpg">
              </a>
    </div>
    <div class="col-xs-12 col-sm-8 col-md-5 wrap-best-content">
        <div class="best-content-tag tag-color">
          <a>#whatshappening</a>
          <a>#Tucson</a>
          <a>#AZ</a>
        </div>
        <div class="best-content-title">
          <h2>Whatshappening Launched</h2>
        </div>
        <div class="best-content-comment">
          <p>Whathappening was founded by two developer. This</p>
        </div>
        <div class="best-author">
          <a href="#" class="best-author-img">
            <img src="http://localhost/placenow/img/profile-image.jpg" alt="" class="media-object img-circle uploader-profile-image">
          </a>
          <a class="best-author-name">By Dale Kim</a>
          <p class="best-posted-at">
                          06-29-16</p>
                    </div>
      </div>
    </div>

    

<!--
    <div class="col-xs-12 col-sm-8 col-md-4 wrap-popular-tag wrap-margin">
      <div class="tag-title">Popular Tags</div>
      <?php foreach( $nearbyplace_picture as $tag ): ?>
      <div class="col-xs-6 col-sm-8 col-md-6 wrap-tag-img">
          <a href="<?php echo e(url('/photo/'.Crypt::encrypt($tag->id))); ?>" class="popular-tag-img">
            <img class="" src="<?php echo e($tag->pic_location); ?>">
            <div class="tag-cover">#tag</div>
            <?php /* <?php echo e($picture->distance); ?> */ ?>
          </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
-->

    <div class="col-xs-12 col-sm-8 col-md-4 wrap-popular-tag wrap-margin">
      <div class="tag-title">Popular Tags</div>
            <div class="col-xs-6 col-sm-8 col-md-12 wrap-tag-img">
                <a href="http://localhost/placenow/photo/eyJpdiI6IlI5N0s2THlcL1RKMlwvejFTUytxZnBFUT09IiwidmFsdWUiOiJDcnpzTzhTaDFVTTRpS2l6SkdwcWJ3PT0iLCJtYWMiOiJhNmJkM2NhM2JmMTI4ZmU3MWQ1ZjY5MThiMDRlNDVkMmQ2Mzg1ZTcyMmNlNjc1MWYyZGU4ZmFjY2VjMjNkMmQ4In0=" class="popular-tag-img">
                  <?php /* <img class="" src="img/Tucson2016-06-29--05-37-38am.jpg"> */ ?>
                  <div class="tag-cover">#poketmongo</div>
                </a>
            </div>
            <div class="col-xs-6 col-sm-8 col-md-6 wrap-tag-img">
          <a href="http://localhost/placenow/photo/eyJpdiI6Im9xdWhyRFloakpCQU9CVWl6M21uNkE9PSIsInZhbHVlIjoid083THdnZElBTlpKWEkzbGljQ1wvR1E9PSIsIm1hYyI6ImU2NGQ5NzViZGI3Y2FlMDRhZDgyMzI5ZmQ4ZjU0YjdiZThkNDU4ZjExZGIxZDBmOTRhMWQyODgzZTllNDZjYzQifQ==" class="popular-tag-img">
            <?php /* <img class="" src="img/Tucson2016-06-29--05-38-55am.jpg"> */ ?>
            <div class="tag-cover">#whatshappening</div>
                      </a>
      </div>
            <div class="col-xs-6 col-sm-8 col-md-6 wrap-tag-img">
          <a href="http://localhost/placenow/photo/eyJpdiI6IkdMeEliakJBQkRvSThDanVKNGRpYVE9PSIsInZhbHVlIjoiNVZxd3hZNkN5TXhYMTdrclF0OXU2QT09IiwibWFjIjoiNGYyMWQ3ZTk5MzEyNGYxZjAyYjI5OGQxNzk4M2JhODI5ZTNkNmMyMzA2YjY5OGFlMDg0MTQwMjkxY2RmYmMzYiJ9" class="popular-tag-img">
            <?php /* <img class="" src="img/Tucson2016-06-29--05-41-31am.jpg"> */ ?>
            <div class="tag-cover">#tucson</div>
                      </a>
      </div>
            <div class="col-xs-6 col-sm-8 col-md-4 wrap-tag-img">
          <a href="http://localhost/placenow/photo/eyJpdiI6IlUzV3ZESnYrc3F5bHZseXF2b3RldkE9PSIsInZhbHVlIjoiTGVzbFZUZ2Q1ZnZLbUZ6eDZUUGFHQT09IiwibWFjIjoiYThmYTVjOWNiYTE0NWUxNDQ2MTU1NjllOTVkNWY1ZmI1YmY1ODRiMWQxNDVlYjk3Mzk5YThmODNkOWZmNDkzOCJ9" class="popular-tag-img">
            <?php /* <img class="" src="img/Tucson2016-06-28--12-08-51am.jpg"> */ ?>
            <div class="tag-cover">#google</div>
                      </a>
      </div>
            <div class="col-xs-6 col-sm-8 col-md-4 wrap-tag-img">
          <a href="http://localhost/placenow/photo/eyJpdiI6IkI0THBXUmFkUEtLbVRTb2xnZlc2c1E9PSIsInZhbHVlIjoiNGk3WWVcL2d5UXQ0QWcwSjR4NFVMa3c9PSIsIm1hYyI6IjVjZTZmNWQ0MjhhMjE5MjFmOWIyYmE2ZjQxYzZjNjBhOGVlYjNiNjEwNzNlMzljZDVjNDViOGVjYjc0MmQxNDYifQ==" class="popular-tag-img">
            <?php /* <img class="" src="img/Tucson2016-06-29--04-54-40am.jpg"> */ ?>
            <div class="tag-cover">#universityofarizona</div>
                      </a>
      </div>
            <div class="col-xs-6 col-sm-8 col-md-4 wrap-tag-img">
          <a href="http://localhost/placenow/photo/eyJpdiI6Im43T05Oa2NWcmRlTjdjeDlFcFp4UkE9PSIsInZhbHVlIjoiSm95cjJSY1lPRUVQTWk5QWkwWGt1UT09IiwibWFjIjoiNGExYWM5YTRiOGFmYjY1N2Q5YzJhOTRmNzQxMWIxMzkzM2UwMTVjOWY5ZjY3MjgyZDg1YTYyZGQyMWFiODg2ZiJ9" class="popular-tag-img">
            <?php /* <img class="" src="img/Tucson2016-06-28--01-19-17am.jpg"> */ ?>
            <div class="tag-cover">#tag</div>
                      </a>
      </div>
          </div>


<div class="col-xs-12 col-sm-8 col-md-5 wrap-best-2 wrap-margin">
      <!--<div class="best-title">It's Happening Now</div>-->
      <a href="http://localhost/placenow/photo/eyJpdiI6Im9xdWhyRFloakpCQU9CVWl6M21uNkE9PSIsInZhbHVlIjoid083THdnZElBTlpKWEkzbGljQ1wvR1E9PSIsIm1hYyI6ImU2NGQ5NzViZGI3Y2FlMDRhZDgyMzI5ZmQ4ZjU0YjdiZThkNDU4ZjExZGIxZDBmOTRhMWQyODgzZTllNDZjYzQifQ==" class="wrap-best-img">
        <img class="img-responsive" alt="Responsive image" src="img/Tucson2016-07-09--12-07-35am.jpg">
              </a>
              <div class="wrap-best-content-2">
                <div class="best-content-tag tag-color">
          <a>#whatshappening</a>
          <a>#Tucson</a>
          <a>#AZ</a>
        </div>
                  <div class="best-content-title">
                    <h2>Whatshappening Launched</h2>
                  </div>
                  <div class="best-author">
          <a href="#" class="best-author-img">
            <img src="http://localhost/placenow/img/profile-image.jpg" alt="" class="media-object img-circle uploader-profile-image">
          </a>
          <a class="best-author-name">By Dale Kim</a>
          <p class="best-posted-at">
                          06-29-16</p>
                    </div>
              </div>
    </div>

    <div class="col-xs-12 col-sm-8 col-md-3 wrap-best-3 wrap-margin">
      <!--<div class="best-title">It's Happening Now</div>-->
      <a href="http://localhost/placenow/photo/eyJpdiI6Im9xdWhyRFloakpCQU9CVWl6M21uNkE9PSIsInZhbHVlIjoid083THdnZElBTlpKWEkzbGljQ1wvR1E9PSIsIm1hYyI6ImU2NGQ5NzViZGI3Y2FlMDRhZDgyMzI5ZmQ4ZjU0YjdiZThkNDU4ZjExZGIxZDBmOTRhMWQyODgzZTllNDZjYzQifQ==" class="wrap-best-img">
        <img class="img-responsive" alt="Responsive image" src="img/Tucson2016-07-09--12-07-35am.jpg">
              </a>
              <div class="wrap-best-content-3"><div class="best-content-tag tag-color">
          <a>#whatshappening</a>
          <a>#Tucson</a>
          <a>#AZ</a>
        </div>
                  <div class="best-content-title">
                    <h2>Whatshappening Launched</h2>
                  </div>
                  <div class="best-author">
          <a href="#" class="best-author-img">
            <img src="http://localhost/placenow/img/profile-image.jpg" alt="" class="media-object img-circle uploader-profile-image">
          </a>
          <a class="best-author-name">By Dale Kim</a>
          <p class="best-posted-at">
                          06-29-16</p>
                    </div>
              </div>
    </div>




      <div class="col-md-12 separator-city-top"></div>


<div class="col-md-1"></div>
<div class="col-xs-12 col-sm-8 col-md-11 popular-city-title">
  <h2>Popular City</h2>
  <!--<p>find out what's happening in these cities</p>-->
</div>


<div class="col-md-1"></div>

<?php foreach($popular_cities_pictures as $pcp): ?>
<div class="col-xs-12 col-sm-8 col-md-7">
  <div class="wrap-city wrap-city-margin">
    <a href="<?php echo e(url('/photo/'.Crypt::encrypt($pcp['id']))); ?>" class="wrap-city-img">
      <img class="img-responsive" alt="Responsive image" src="<?php echo e($pcp['pic_loc']); ?>">
      <?php /* <?php echo e($pc['city']); ?> */ ?>
    </a>
    <div class="col-xs-12 col-sm-8 col-md-8 wrap-city-content">
      <div class="city-content-tag tag-color">
        <a>#wer</a>
        <a>#Tucson</a>
        <a>#AZ</a>
      </div>
      <div class="city-content-title">
        <h3>Whatshappening Launched</h3>
      </div>
      <div class="city-content-comment">
        Whathappening was founded by two developer. This 
      </div>
      <div class="city-author">
        <a href="#" class="city-author-img">
          <img src="<?php echo e(url('/img/profile-image.jpg')); ?>" alt="" class="media-object img-circle">
        </a>
        <a class="city-author-name">By </a>
        <p class="city-posted-at"></p>
      </div>
    </div>
  </div>

</div>
<?php endforeach; ?>

<div class="col-xs-12 col-sm-8 col-md-3 before-wrap-city-2">
  <div class="wrap-city-2 wrap-city-margin">
    <a href="http://localhost/placenow/photo/eyJpdiI6IjJpNFdpSUJNZU5DZXVSQWI0UGR3dGc9PSIsInZhbHVlIjoidEQ2emluMjZFZ1hPRGpIRWhlRUcrQT09IiwibWFjIjoiNWU2ZmNlODM3YjBiYzQyNjZkOWFlZTIzNjA5OTI1ZmJmNjFmYjRjNjA0ODNiNjhmNWViNWE5Nzc3OGZlMDVmMCJ9" class="wrap-city-img-2">
      <img class="img-responsive" alt="Responsive image" src="img/Tucson2016-06-29--04-54-40am.jpg">
          </a>
    <div class="wrap-city-content-2">
      <div class="city-content-tag tag-color">
        <a>#wer</a>
        <a>#Tucson</a>
        <a>#AZ</a>
      </div>
      <div class="city-content-title-2">
        <h3>Whatshappening Launched</h3>
      </div>
    </div>
  </div>

  <div class="wrap-city-2 wrap-city-margin">
    <a href="http://localhost/placenow/photo/eyJpdiI6IjJpNFdpSUJNZU5DZXVSQWI0UGR3dGc9PSIsInZhbHVlIjoidEQ2emluMjZFZ1hPRGpIRWhlRUcrQT09IiwibWFjIjoiNWU2ZmNlODM3YjBiYzQyNjZkOWFlZTIzNjA5OTI1ZmJmNjFmYjRjNjA0ODNiNjhmNWViNWE5Nzc3OGZlMDVmMCJ9" class="wrap-city-img-2">
      <img class="img-responsive" alt="Responsive image" src="img/Tucson2016-06-29--04-54-40am.jpg">
          </a>
    <div class="wrap-city-content-2">
      <div class="city-content-tag tag-color">
        <a>#wer</a>
        <a>#Tucson</a>
        <a>#AZ</a>
      </div>
      <div class="city-content-title-2">
        <h3>Whatshappening Launched</h3>
      </div>
    </div>
  </div>

  <div class="wrap-city-2 wrap-city-margin">
    <a href="http://localhost/placenow/photo/eyJpdiI6IjJpNFdpSUJNZU5DZXVSQWI0UGR3dGc9PSIsInZhbHVlIjoidEQ2emluMjZFZ1hPRGpIRWhlRUcrQT09IiwibWFjIjoiNWU2ZmNlODM3YjBiYzQyNjZkOWFlZTIzNjA5OTI1ZmJmNjFmYjRjNjA0ODNiNjhmNWViNWE5Nzc3OGZlMDVmMCJ9" class="wrap-city-img-2">
      <img class="img-responsive" alt="Responsive image" src="img/Tucson2016-06-29--04-54-40am.jpg">
          </a>
    <div class="wrap-city-content-2">
      <div class="city-content-tag tag-color">
        <a>#wer</a>
        <a>#Tucson</a>
        <a>#AZ</a>
      </div>
      <div class="city-content-title-2">
        <h3>Whatshappening Launched</h3>
      </div>
    </div>
  </div>

</div>








<div class="col-md-12 separator-place-top"></div>

<div class="col-md-1"></div>
<div class="col-xs-12 col-sm-8 col-md-11 popular-place-title">
  <h2>Popular Place</h2>
  <!--<p>find out what's happening in these cities</p>-->
</div>

<?php for( $i = 0; $i < 5; $i++ ): ?>

  <div class="col-md-1"></div>
  <div class="col-xs-4 col-sm-6 col-md-11 wrap-place wrap-place-margin">
    <div class="col-md-4">
      <a href="<?php echo e(url('/photo/'.Crypt::encrypt($whatshappening_city[$i]->id))); ?>" class="wrap-place-img">
        <img class="img-responsive" alt="" src="<?php echo e($whatshappening_city[$i]->pic_location); ?>">
        <?php /* <?php echo e($wc->location); ?> */ ?>
      </a>
    </div>
    <div class="col-md-7">
      <div class="wrap-place-content">
        <div class="place-content-tag tag-color">
          <a>#wer</a>
          <a>#Tucson</a>
          <a>#AZ</a>
        </div>
        <div class="place-content-title-2">
          <h3>Whatshappening Launched</h3>
        </div>
      </div>
    </div>
  </div>

<?php endfor; ?>



  </div><!-- end of row -->


<!--
  <div class="row grid">
    <div class="grid-sizer col-xs-4 col-sm-6 col-md-2"></div>    

    <?php foreach( $best_place as $bp ): ?>

    <div class="grid-item col-xs-12 col-sm-8 col-md-8 wrap-best-place grid-padding">
      <a>
        <img class="img-responsive" alt="Responsive image" src="<?php echo e($bp->pic_location); ?>">
      </a>
    </div>
    <div class="grid-item col-xs-12 col-sm-8 col-md-4 grid-padding">
      <h2>Title</h2>
      <p>Content</p>
    </div>

    <?php endforeach; ?>

  </div>
-->
</div>

</div>

<div class="container">

  <div class="col-xs-12 col-sm-8 col-md-12 popular-place-title">
    <h2>Latest</h2>
    <!--<p>find out what's happening in these cities</p>-->
  </div>
<div class="col-md-1"></div>
<div class="col-md-10">
<?php for( $i = 0; $i < count($whatshappening_city); $i++ ): ?>

  <div class="col-xs-4 col-sm-6 col-md-4 wrap-latest wrap-margin">
    <a href="<?php echo e(url('/photo/'.Crypt::encrypt($whatshappening_city[$i]->id))); ?>" class="wrap-latest-img">
      <img class="img-responsive" alt="" src="<?php echo e($whatshappening_city[$i]->pic_location); ?>">
      <?php /* <?php echo e($wc->location); ?> */ ?>
    </a>
    <div class="latest-info">

    </div>
  </div>

<?php endfor; ?>
</div>
<div class="col-md-1"></div>
</div>

<div class="container latest-container">

  <div class="row">

    <div class="">



    </div>

  </div>


</div>

<!--
<div class="row" id="dropdown-sort">
    <div class="col-md-1"></div>
    <div class="col-md-2">
      <div class="dropdown">
              <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Sort By
                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="sort/1">Date</a></li>
                <li><a href="sort/2">Popularity</a></li>
                <li><a href="sort/3">City</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="#">etc...</a></li>
              </ul>
        </div>
    </div>
</div>-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>