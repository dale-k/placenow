<?php $__env->startSection('title','Place Now - welcome'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/city.blade.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container wrap-margin">

  <div class="row">

    <div class="col-xs-12 wrap-city-info padding-block hidden-md hidden-lg">
      <div class="city-info border-radius">
        <div class="city-info-inner">
          <h1><?php echo e($city_ary['city']); ?></h1>
          <div class="wrap-follow-btn">
            <?php if($city_ary['user_follow_city'] == 'yes'): ?>
              <a role="button" href="<?php echo e(url('unfollowcity/'.$city_ary['city'])); ?>">Unfollow</a>
            <?php elseif(Auth::guest()): ?>
              <a role="button" href="<?php echo e(url('followcity/'.$city_ary['city'])); ?>">Follow</a>
            <?php else: ?>
              <a role="button" href="<?php echo e(url('followcity/'.$city_ary['city'])); ?>">Follow</a>
            <?php endif; ?>
          </div>
        
          <div class="wrap-about-city">
            <div class="wrap-follow-city">
              <b><?php echo e($city_ary['follow_count']); ?></b> followers
            </div>
            <div class="number-of-post">
              <b><?php echo e($city_ary['post_count']); ?></b> posts
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xs-12 col-sm-8 col-md-4 padding-block padding-remove hidden-lg">
      <div class="city-box border-radius">
        <div class="city-box-inner">
          <span class="glyphicon glyphicon-comment chat" aria-hidden="true"></span>
        </div>
      </div>
    </div>

    <?php if(count($most_popular)): ?>
    <div class="col-xs-12 col-sm-8 col-md-6 wrap-best padding-remove">
      <a href="<?php echo e(url('/photo/'.$most_popular[0]['id'])); ?>" class="wrap-best-img border-radius">
        <img class="img-responsive" alt="Responsive image" src="<?php echo e(url($most_popular[0]['pic_location'])); ?>">
        
        <div class="wrap-best-content">
        
          <?php if( $most_popular[0]['title'] != '' ): ?>
          <div class="best-content">
            <h3><?php echo e($most_popular[0]['title']); ?></h3>
          </div>
          <?php elseif( $most_popular[0]['comment'] != '' ): ?>
          <div class="best-content">
            <p><?php echo e($most_popular[0]['comment']); ?></p>
          </div>
          <?php elseif( count( $most_popular[0]->tag ) != 0 ): ?>
          <div class="best-content">
            <?php foreach( $most_popular[0]->tag as $mp ): ?>
              <a>#<?php echo e($mp->type); ?></a>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <p class="best-posted-at">
            @ <?php echo e($most_popular[0]->place->location); ?>

            By <?php echo e($most_popular[0]->user->user); ?>, 
            <?php echo e(trimCreatedAt($most_popular[0]['created_at'])); ?>

          </p>

        </div>

      </a>
    </div>
    <?php endif; ?>

    <div class="col-xs-12 col-sm-8 col-md-6 padding-block padding-remove hidden-xs">
      <div class="city-info border-radius">
        <div class="city-info-inner">
          <h1><?php echo e($city_ary['city']); ?></h1>
          <div class="wrap-follow-btn">
            <?php if($city_ary['user_follow_city'] == 'yes'): ?>
              <a role="button" href="<?php echo e(url('unfollowcity/'.$city_ary['city'])); ?>">Unfollow</a>
            <?php elseif(Auth::guest()): ?>
              <a role="button" href="<?php echo e(url('followcity/'.$city_ary['city'])); ?>">Follow</a>
            <?php else: ?>
              <a role="button" href="<?php echo e(url('followcity/'.$city_ary['city'])); ?>">Follow</a>
            <?php endif; ?>
          </div>
        
          <div class="wrap-about-city">
            <div class="wrap-follow-city">
              <b><?php echo e($city_ary['follow_count']); ?></b> followers
            </div>
            <div class="number-of-post">
              <b><?php echo e($city_ary['post_count']); ?></b> posts
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xs-12 col-sm-8 col-md-3 padding-block padding-remove hidden-xs">
      <div class="city-box border-radius">
        <div class="city-box-inner">
          <span class="glyphicon glyphicon-comment chat" aria-hidden="true"></span>
        </div>
      </div>
    </div>

    <?php if(count($most_popular) > 1 && count($most_popular) < 4): ?>
      <?php for( $i = 1; $i < count($most_popular); $i++ ): ?>
      <div class="col-xs-12 col-sm-8 col-md-4 wrap-best wrap-best-2 padding-remove">
        <!--<div class="best-title">It's Happening Now</div>-->
        <div class="wrap-best-2-img border-radius">
          <a href="<?php echo e(url('/photo/'.$most_popular[$i]['id'])); ?>">
            <img class="img-responsive" alt="Responsive image" src="<?php echo e(url($most_popular[$i]['pic_location'])); ?>">
          </a>
          <div class="wrap-best-content-2">
            <?php if( $most_popular[$i]['title'] != '' ): ?>
            <div class="best-content-2">
              <h3><?php echo e($most_popular[$i]['title']); ?></h3>
            </div>
            <?php elseif( $most_popular[$i]['comment'] != '' ): ?>
            <div class="best-content-2">
              <p><?php echo e($most_popular[$i]['comment']); ?></p>
            </div>
            <?php elseif( count( $most_popular[$i]->tag ) != 0 ): ?>
            <div class="best-content-2">
              <?php foreach( $most_popular[$i]->tag as $mp ): ?>
                <a>#<?php echo e($mp->type); ?></a>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <p class="best-posted-at-2">
              @ <a><?php echo e($most_popular[$i]->place->location); ?></a>, 
              By <a><?php echo e($most_popular[$i]->user->user); ?></a>, 
              <?php echo e(trimCreatedAt($most_popular[$i]['created_at'])); ?>

            </p>
          </div>
        </div>
      </div>
      <?php endfor; ?>
    <?php elseif(count($most_popular) >= 4): ?>
      <?php for( $i = 1; $i < 4; $i++ ): ?>
      <div class="col-xs-12 col-sm-8 col-md-4 wrap-best wrap-best-2 padding-remove">
        <!--<div class="best-title">It's Happening Now</div>-->
        <div class="wrap-best-2-img border-radius">
          <a href="<?php echo e(url('/photo/'.$most_popular[$i]['id'])); ?>">
            <img class="img-responsive" alt="Responsive image" src="<?php echo e(url($most_popular[$i]['pic_location'])); ?>">
          </a>
          <div class="wrap-best-content-2">
            <?php if( $most_popular[$i]['title'] != '' ): ?>
            <div class="best-content-2">
              <h3><?php echo e($most_popular[$i]['title']); ?></h3>
            </div>
            <?php elseif( $most_popular[$i]['comment'] != '' ): ?>
            <div class="best-content-2">
              <p><?php echo e($most_popular[$i]['comment']); ?></p>
            </div>
            <?php elseif( count( $most_popular[$i]->tag ) != 0 ): ?>
            <div class="best-content-2">
              <?php foreach( $most_popular[$i]->tag as $mp ): ?>
                <a>#<?php echo e($mp->type); ?></a>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <p class="best-posted-at-2">
              @ <a><?php echo e($most_popular[$i]->place->location); ?></a>, 
              By <a><?php echo e($most_popular[$i]->user->user); ?></a>, 
              <?php echo e(trimCreatedAt($most_popular[$i]['created_at'])); ?>

            </p>
          </div>
        </div>
      </div>
      <?php endfor; ?>
    <?php endif; ?>   


    <?php for( $i = 0; $i < count($popular_place); $i++ ): ?>
    <div class="col-xs-6 col-sm-8 col-md-6 wrap-place padding-remove">
      <a href="<?php echo e(url('/place/'.$popular_place[$i]->place->location)); ?>" class="wrap-place-img border-radius">
        <img class="img-responsive" alt="" src="<?php echo e(url($popular_place[$i]->pic_location)); ?>">
        <div>
          <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>&nbsp;
          <?php echo e($popular_place[$i]->place->location); ?>

        </div>
      </a>
    </div>
    <?php endfor; ?>

    <!-- popular Question -->
    <?php if(count($popularQuestion)!=0): ?>

    <div class="col-xs-12 col-sm-6 col-md-6 wrap-popular-question padding-remove">

      <div class="pq-title">
        Ask
      </div>

      <a href="<?php echo e(url('ask/answers/'.$popularQuestion[0]->question)); ?>" class="popular-question border-radius">
        <h4 class="pq-question"><?php echo e($popularQuestion[0]->question); ?></h4>
      </a>

      <div class="pq-btn">
        <p class="pq-asked-by">
          Asked By 
          <a><?php echo e($popularQuestion[0]->user->user); ?></a>, 
          <?php echo e(trimCreatedAt($popularQuestion[0]->created_at)); ?><br>
          <?php echo e($popularQuestion[0]->num_answer); ?> answers
        </p>
      </div>

    </div>

    <?php endif; ?>
    <!-- End - popular Question -->

    <!-- popular tag -->
    <?php for( $i = 0; $i < count($popular_tag); $i++ ): ?>

      <div class="col-md-3 wrap-tag">
        <a href="<?php echo e(url('/tag/'.$popular_tag[$i]->type)); ?>" class="wrap-tag-img tag-3 border-radius">
          <img class="img-responsive" alt="" src="<?php echo e(url($popular_tag_pic[$i]->pic_location)); ?>">
          <div>#<?php echo e($popular_tag[$i]->type); ?> -  <?php echo e($popular_tag[$i]->type_count); ?> posts</div>
        </a>
      </div>

    <?php endfor; ?>

  </div>    

</div><!-- end of container -->


<?php /* <div class="container wrap-popular-place padding-remove">
  <div class="row padding-block">
    <?php for( $i = 0; $i < count($popular_place); $i++ ): ?>
    <div class="col-xs-6 col-sm-8 col-md-6 wrap-place padding-remove">
      <a href="<?php echo e(url('/place/'.$popular_place[$i]->place->location)); ?>" class="wrap-place-img border-radius">
        <img class="img-responsive" alt="" src="<?php echo e(url($popular_place[$i]->pic_location)); ?>">
        <div>
          <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>&nbsp;
          <?php echo e($popular_place[$i]->place->location); ?>

        </div>
      </a>
    </div>
    <?php endfor; ?>
  </div>
</div> */ ?>

<?php /* <div class="container wrap-fluid-tags padding-remove">

  <div class="row">
    <?php for( $i = 0; $i < count($popular_tag); $i++ ): ?>
      <?php if( $i == 0 ): ?>
    <div class="col-md-6 wrap-tag">
      <a href="<?php echo e(url('/tag/'.$popular_tag[$i]->type)); ?>" class="wrap-tag-img tag-1 border-radius">
        <img class="img-responsive" alt="" src="<?php echo e(url($popular_tag_pic[$i]->pic_location)); ?>">
        <div>#<?php echo e($popular_tag[$i]->type); ?> -  <?php echo e($popular_tag[$i]->type_count); ?> posts</div>
      </a>
    </div>
      <?php elseif( $i == 1 ): ?>
    <div class="col-md-6 wrap-tag">
      <a href="<?php echo e(url('/tag/'.$popular_tag[$i]->type)); ?>" class="wrap-tag-img tag-2 border-radius">
        <img class="img-responsive" alt="" src="<?php echo e(url($popular_tag_pic[$i]->pic_location)); ?>">
        <div>#<?php echo e($popular_tag[$i]->type); ?> -  <?php echo e($popular_tag[$i]->type_count); ?> posts</div>
      </a>
    </div>
      <?php else: ?>
    <div class="col-md-3 wrap-tag">
      <a href="<?php echo e(url('/tag/'.$popular_tag[$i]->type)); ?>" class="wrap-tag-img tag-3 border-radius">
        <img class="img-responsive" alt="" src="<?php echo e(url($popular_tag_pic[$i]->pic_location)); ?>">
        <div>#<?php echo e($popular_tag[$i]->type); ?> -  <?php echo e($popular_tag[$i]->type_count); ?> posts</div>
      </a>
    </div>
      <?php endif; ?>


    <?php endfor; ?>
  </div>
</div> */ ?>

<div class="container padding-remove">

  <div class="row padding-remove">

  </div>

  <div class="row grid">

    <div class="col-xs-12 col-sm-6 col-md-3 grid-sizer"></div>

    <?php if(count($most_popular) > 4): ?>

    <?php for($i = 4; $i < count($most_popular); $i++): ?>
    <div class="col-xs-12 col-sm-6 col-md-3 wrap-nearby grid-item padding-block">

      <div class="nearby border-radius">

        <a href="<?php echo e(url('photo/'.$most_popular[$i]->id)); ?>" class="wrap-nearby-img">
          <img class="img-responsive" alt="Responsive image" src="<?php echo e(url($most_popular[$i]->pic_location)); ?>">
        </a>

        <div class="nearby-content">

          <a class="nearby-location" href="<?php echo e(url( 'place/'.$most_popular[$i]->place->location )); ?>">
            <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
            <?php echo e($most_popular[$i]->place->location); ?> ( <?php echo e(roundDistance($most_popular[$i]->distance)); ?> )
          </a>

          <?php if( $most_popular[$i]->title != '' ): ?>
            <h4><?php echo e($most_popular[$i]->title); ?></h4>
          <?php endif; ?>

          <?php if( $most_popular[$i]->comment != '' ): ?>
            <p><?php echo e($most_popular[$i]->comment); ?></p>
          <?php endif; ?>

          <?php if(count($most_popular[$i]->tag)>0): ?>
            <div class="wrap-tags">
            <?php foreach($most_popular[$i]->tag as $tag): ?>
              <a href="">#<?php echo e($tag->type); ?></a>
            <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <div class="wrap-user-time">
            <div class="nearby-user">By <?php echo e($most_popular[$i]->user->user); ?>,</div> 
            <div class="nearby-when"><?php echo e(trimCreatedAt($most_popular[$i]->created_at)); ?></div>
          </div>
        </div>

      </div>
    </div>
    <?php endfor; ?>

    <?php endif; ?>

  </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>