<?php $__env->startSection('title','Tag - #'.$select_tag['tag'].' - Location'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/tag.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
<style>

</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tag-type',' - Location'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.tag_navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">


	<div class="row wrap-content">
		
  	<div class="col-md-2" style="height:1px;"></div>
		<div class="col-md-8 wrap-image">


<?php $__env->startSection('load-image'); ?>
<div class="row img-container">
	<?php foreach( $loctag_pictures as $place ): ?>
		<div class="place-name"><h2><?php echo e($place->location); ?></h2></div>
		<div class="row img-container">
			<?php foreach($place->picturebydate(5) as $picture): ?>
				<div class="popular-img-wrap col-md-4 col-xs-12">
		          <span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;<?php echo e(trimCreatedAt($picture->created_at)); ?>

		          <a href="<?php echo e(url('/photo/'.$picture->id)); ?>">
		          <img class='img-responsive' alt="" src="<?php echo e(url($picture->pic_location)); ?>"></a>
		          <div class="img-counts col-md-12 col-xs-12">
		             <div class="col-md-3 col-xs-3 pic-counts"> <?php echo e($picture->vote_count); ?> <span class="glyphicon glyphicon-heart" aria-hidden="true"></span></div>
		             <div class="col-md-3 col-xs-3 pic-counts"><?php echo e($picture->favor_count); ?><span class="glyphicon glyphicon-star" aria-hidden="true"></span></div>
		             <div class="col-md-3 col-xs-3 pic-counts"> <?php echo e($picture->recommend_count); ?> <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span></div>
		             <div class="col-md-3 col-xs-3 pic-counts"> <?php echo e($picture->view_count); ?> <span class="glyphicon glyphicon-play" aria-hidden="true"></span></div>
		          </div>
		            <div class="tag-list col-md-12 col-xs-12">
		              <?php foreach($picture->tag as $tag): ?>
		              <a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;
		              <?php endforeach; ?>
		            </div>
		            
		          </div>
			<?php endforeach; ?>
		</div>
	<?php endforeach; ?>
</div>



		</div>    
	</div>

</div>



<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/tag.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>