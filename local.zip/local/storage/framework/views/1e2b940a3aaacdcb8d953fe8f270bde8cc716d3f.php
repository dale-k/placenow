<?php $__env->startSection('title','Pictures'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_picture_blade.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/picture_blade.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php /* <?php echo $__env->make('layouts.top_picture_blade_test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> */ ?>
<div class="timeline-display">

<div class="container">

	<div class="row wrap-content">
				 <!-- NOW <BR> -->
		       <?php /* <?php echo e($picture->id); ?><br> */ ?>
				<!-- Before <br> -->
			<?php /* <?php for($i=count($pictures_before)-1; $i>=0;$i--): ?> */ ?>
				<?php /* <?php echo e($pictures_before[$i]->id); ?>&nbsp;<?php echo e($pictures_before[$i]->location); ?>&nbsp;<?php echo e($pictures_before[$i]->created_at); ?>&nbsp;<?php echo e($pictures_before[$i]->distance); ?> */ ?>
				<?php /* &nbsp;<?php echo e($pictures_before[$i]->user->user); ?><br> */ ?>
			<?php /* <!-- <?php endfor; ?> --> */ ?>
				<!-- After <br> -->
			<?php /* <?php for( $i=0 ; $i<count( $pictures_after );$i++): ?> */ ?>
				<?php /* <?php echo e($pictures_after[$i]->id); ?>&nbsp;<?php echo e($pictures_after[$i]->location); ?>&nbsp;<?php echo e($pictures_after[$i]->created_at); ?>&nbsp;<?php echo e($pictures_after[$i]->distance); ?><br> */ ?>
			<?php /* <?php endfor; ?> */ ?>
			<!-- <br> -->
			<!-- bHistory<br> -->

			<?php /* <?php for( $i=0;$i<count($history_before);$i++): ?> */ ?>
				<?php /* <?php echo e($history_before[$i]->picture_id); ?>&nbsp;<?php echo e($history_before[$i]->user_id); ?> <br> */ ?>
			<?php /* <?php endfor; ?>			 */ ?>
			<!-- aHistory <br> -->
			<?php /* <?php foreach( $history_after as $hafter): ?> */ ?>
				<?php /* <?php echo e($hafter->picture_id); ?>&nbsp;<?php echo e($hafter->user_id); ?> <br> */ ?>

			<?php /* <?php endforeach; ?> */ ?>
		
			<!-- Follow list before<br> -->
			<?php /* <?php for($i=0;$i<count($followlist_before);$i++): ?> */ ?>
				<?php /* <?php echo e($followlist_before[$i]); ?><br> */ ?>
			<?php /* <?php endfor; ?> */ ?>


			<?php /* <?php for($i=0; $i<count($userids_before);$i++): ?> */ ?>
				<?php /* <?php echo e($userids_before[$i]); ?><br> */ ?>
			<?php /* <?php endfor; ?> */ ?>

<!-- Start of pictures before  -->
	


<?php for($i = count($pictures_before)-1 ; $i >=0 ;$i--): ?>
			
			<div class="wrap-image row">
			
			<div class="img-before-<?php echo e($i); ?> each-img <?php if($i==count($pictures_before)-1): ?><?php echo e('first-img'); ?><?php endif; ?>">
			<div id="img-location-info row">
				<h1 class="picture-title col-md-12"><a href="<?php echo e(url('place/'.$pictures_before[$i]->place->location)); ?>"><?php echo e($pictures_before[$i]->place->location); ?> </a></h1>
				<div class="col-md-8">
					<ol class="breadcrumb wrap-pic-location">
						<li><a href="<?php echo e(url('city/'.$pictures_before[$i]->place->city)); ?>"> <?php echo e($pictures_before[$i]->place->city); ?> </a></li>
						<li><a href="<?php echo e(url('state/'.$pictures_before[$i]->place->state)); ?>"> <?php echo e($pictures_before[$i]->place->state); ?> </a></li>
						<li><a href="<?php echo e(url('country/'.$pictures_before[$i]->place->country)); ?>"> <?php echo e($pictures_before[$i]->place->country); ?></a></li>
					</ol>
				</div>
			</div>
					
				<div class="col-md-8 col-xs-12 no-padding">
				<div id="uploaded-time" class="col-md-12"><span class="glyphicon glyphicon-time" aria-hidden="true"></span><?php echo e(trimCreatedAt($pictures_before[$i]->created_at)); ?></div>
					<img class="col-md-12 shown img-hidden" alt="Responsive image" src=" <?php echo e(url($pictures_before[$i]->pic_location)); ?>">
					<div id="mid_section" class="col-md-12 col-xs-12">
					
						<div id="tag_list" class="col-md-4">
						
							<?php foreach($pictures_before[$i]->tag as $tag): ?>
							<a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;&nbsp;&nbsp;
							<?php endforeach; ?>
						</div>
						<div id ="pic_btns" >
							<?php if($history_before[$i]->voted): ?>
								<button type="button" id="vote_btn" class="btn btn-default" onclick="postVote('0','<?php echo e(Crypt::encrypt($pictures_before[$i]->id)); ?>');" disabled>
					            <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_before[$i]->vote_count); ?>

					        </button>
							<?php else: ?>
								<button type="button" id="vote_btn" class="btn btn-default" onclick="postVote('0','<?php echo e(Crypt::encrypt($pictures_before[$i]->id)); ?>');">
					            <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_before[$i]->vote_count); ?>

					        </button>
							<?php endif; ?>
								
							<?php if($history_before[$i]->favored): ?>
								<button type="button" id="favor_btn" class="btn btn-default" onclick="postVote('1','<?php echo e(Crypt::encrypt($pictures_before[$i]->id)); ?>');" disabled>
					            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_before[$i]->favor_count); ?>

					        </button>
							<?php else: ?>
								<button type="button" id="favor_btn" class="btn btn-default" onclick="postVote('1','<?php echo e(Crypt::encrypt($pictures_before[$i]->id)); ?>');">
					            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_before[$i]->favor_count); ?>

					        </button>
							<?php endif; ?>

							<?php if($history_before[$i]->recommended): ?>
								<button type="button" id="recommend_btn" class="btn btn-default" onclick="postVote('2','<?php echo e(Crypt::encrypt($pictures_before[$i]->id)); ?>');" disabled>
					            <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_before[$i]->recommend_count); ?>

					        </button>
							<?php else: ?>
								<button type="button"  id="recommend_btn" class="btn btn-default" onclick="postVote('2','<?php echo e(Crypt::encrypt($pictures_before[$i]->id)); ?>');">
					            <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_before[$i]->recommend_count); ?>

					        </button>
							<?php endif; ?>
					    </div>  <!-- end of pic btn	 -->
					</div>  <!-- end of mid section -->
				</div> <!-- end of left side  img and tag and btns   -->
				

				<div class="wrap-user-information col-md-4 col-xs-12 comment_section">
				<div class="picInfo-wrapp">
					<div class="media">
					  <div class="media-left">
					    <a href="#">
					      <img src="<?php echo e(url('/img/profile-image.jpg')); ?>" alt="" class="media-object img-circle uploader-profile-image">
					    </a>
					  </div>
					  <div class="media-body">
					    <h4 class="media-heading">
							<a class ="author" href="<?php echo e(url('/people/'.$pictures_before[$i]->user->user)); ?>"><?php echo e($pictures_before[$i]->user->user); ?></a>
							<ul>
								<?php if($followlist_before[$i] > 0): ?>
								<li>
									<?php if($followlist_before[$i] ==0): ?>
										<a href="<?php echo e(url('/follow/'.$pictures_before[$i]->user->user)); ?>">
								    	follow
										</a>
									<?php else: ?>
										<a href="<?php echo e(url('/unfollow/'.$pictures_before[$i]->user->user)); ?>">
										unfollow
										</a>
									<?php endif; ?>
								</li>
								<?php endif; ?>
							</ul>
					    </h4>
					    
					    <div class="pic_comment no-padding"> <?php echo e($pictures_before[$i]->comment); ?></div>
					    
					  </div>
					</div>
		         

		        </div>	
				</div>
			</div>
			</div>
<?php endfor; ?>	



<!-- End of pictures before    -->


			<div class="img-now each-img show-img">
			
			<div class="wrap-image row now">
				<div id="img-location-info">
			<h1 class="picture-title"><a href="<?php echo e(url('place/'.$picture->place->location)); ?>">@ <?php echo e($picture->place->location); ?> </a></h1>
			<div class="">
				<ol class="breadcrumb wrap-pic-location">
					<li><a href="<?php echo e(url('city/'.$picture->place->city)); ?>"> <?php echo e($picture->place->city); ?> </a></li>
					<li><a href="<?php echo e(url('state/'.$picture->place->state)); ?>"> <?php echo e($picture->place->state); ?> </a></li>
					<li><a href="<?php echo e(url('country/'.$picture->place->country)); ?>"> <?php echo e($picture->place->country); ?></a></li>
				</ol>
			</div>
			</div>
				<div id="uploaded-time" class="col-md-12">
						<?php echo e(trimCreatedAt($picture->created_at)); ?>

					</div>
				<div class="col-md-8 col-xs-12 no-padding">
				<div class="col-md-12 col-xs-12 img-resizer">
				<img class="shown image-now img-hidden" alt="Responsive image" src=" <?php echo e(url($picture->pic_location)); ?>">
				</div>
				<div id="mid_section" class="col-md-12">
				
				<div id="tag_list" class="col-md-4">
					<?php foreach($tags as $tag): ?>
					<a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;&nbsp;&nbsp;
					<?php endforeach; ?>
				</div>
				<div id ="pic_btns" >
					<?php if($voteHistory->voted): ?>
						<button type="button" id="vote_btn" class="btn btn-default" onclick="postVote('0','<?php echo e(Crypt::encrypt($picture->id)); ?>');" disabled>
			            <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>&nbsp;<?php echo e($picture->vote_count); ?>

			        </button>
					<?php else: ?>
						<button type="button" id="vote_btn" class="btn btn-default" onclick="postVote('0','<?php echo e(Crypt::encrypt($picture->id)); ?>');">
			            <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>&nbsp;<?php echo e($picture->vote_count); ?>

			        </button>
					<?php endif; ?>
						
					<?php if($voteHistory->favored): ?>
						<button type="button" id="favor_btn" class="btn btn-default" onclick="postVote('1','<?php echo e(Crypt::encrypt($picture->id)); ?>');" disabled>
			            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;<?php echo e($picture->favor_count); ?>

			        </button>
					<?php else: ?>
						<button type="button" id="favor_btn" class="btn btn-default" onclick="postVote('1','<?php echo e(Crypt::encrypt($picture->id)); ?>');">
			            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;<?php echo e($picture->favor_count); ?>

			        </button>
					<?php endif; ?>

					<?php if($voteHistory->recommended): ?>
						<button type="button" id="recommend_btn" class="btn btn-default" onclick="postVote('2','<?php echo e(Crypt::encrypt($picture->id)); ?>');" disabled>
			            <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>&nbsp;<?php echo e($picture->recommend_count); ?>

			        </button>
					<?php else: ?>
						<button type="button"  id="recommend_btn" class="btn btn-default" onclick="postVote('2','<?php echo e(Crypt::encrypt($picture->id)); ?>');">
			            <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>&nbsp;<?php echo e($picture->recommend_count); ?>

			        </button>
					<?php endif; ?>
			    </div>
				</div>
				</div>
				<div class="wrap-user-information col-md-4 col-xs-12 comment_section">
				<div class="picInfo-wrapp">
					<div class="media">
					  <div class="media-left">
					    <a href="#">
					      <img src="<?php echo e(url('/img/profile-image.jpg')); ?>" alt="" class="media-object img-circle uploader-profile-image">
					    </a>
					  </div>
					  <div class="media-body">
					    <h4 class="media-heading">
							<a class ="author" href="<?php echo e(url('/people/'.$picture->user->user)); ?>"><?php echo e($picture->user->user); ?></a>
							<ul>
								<?php if($ch_follow > 0): ?>
								<li>
									<?php if($ch_follow ==0): ?>
										<a href="<?php echo e(url('/follow/'.$picture->user->user)); ?>">
										follow
										</a>
									<?php else: ?>
										<a href="<?php echo e(url('/unfollow/'.$picture->user->user)); ?>">
											unfollow
										</a>
									<?php endif; ?>
								</li>
								<?php endif; ?>
							</ul>
					    </h4>
					    <div class="pic_comment no-padding"> <?php echo e($picture->comment); ?></div>
					    
					  </div>
					</div>
		         

		        </div>	
				</div>
			</div>
			</div>
<!--start of pictures after  -->
			




<?php for($j = 0 ; $j < count($pictures_after) ;$j++): ?>
			<div class="img-after-<?php echo e($j); ?> each-img hidden-img <?php if($j==(count($pictures_after)-1)): ?><?php echo e('last-img'); ?><?php endif; ?>">
			
			<div class="wrap-image row">
			<div id="img-location-info">
				<h1 class="picture-title"><a href="<?php echo e(url('place/'.$pictures_after[$j]->place->location)); ?>"><?php echo e($pictures_after[$j]->place->location); ?> </a></h1>
				<div class="">
					<ol class="breadcrumb wrap-pic-location">
						<li><a href="<?php echo e(url('city/'.$pictures_after[$j]->place->city)); ?>"> <?php echo e($pictures_after[$j]->place->city); ?> </a></li>
						<li><a href="<?php echo e(url('state/'.$pictures_after[$j]->place->state)); ?>"> <?php echo e($pictures_after[$j]->place->state); ?> </a></li>
						<li><a href="<?php echo e(url('country/'.$pictures_after[$j]->place->country)); ?>"> <?php echo e($pictures_after[$j]->place->country); ?></a></li>
					</ol>
				</div>
			</div>
				<div id="uploaded-time" class="col-md-12">
					<?php echo e(trimCreatedAt($pictures_after[$j]->created_at)); ?>

				</div>
				<div class="col-md-8 no-padding">
				<img class="col-md-12 shown img-hidden" alt="Responsive image" src=" <?php echo e(url($pictures_after[$j]->pic_location)); ?>">
				<div id="mid_section" class="col-md-12">
				
				<div id="tag_list" class="col-md-4">
				
					<?php foreach($pictures_after[$j]->tag as $tag): ?>
					<a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;&nbsp;&nbsp;
					<?php endforeach; ?>
				</div>
				<div id ="pic_btns" >
					<?php if($history_after[$j]->voted): ?>
						<button type="button" id="vote_btn" class="btn btn-default" onclick="postVote('0','<?php echo e(Crypt::encrypt($pictures_after[$j]->id)); ?>');" disabled>
			            <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_after[$j]->vote_count); ?>

			        </button>
					<?php else: ?>
						<button type="button" id="vote_btn" class="btn btn-default" onclick="postVote('0','<?php echo e(Crypt::encrypt($pictures_after[$j]->id)); ?>');">
			            <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_after[$j]->vote_count); ?>

			        </button>
					<?php endif; ?>
						
					<?php if($history_after[$j]->favored): ?>
						<button type="button" id="favor_btn" class="btn btn-default" onclick="postVote('1','<?php echo e(Crypt::encrypt($pictures_after[$j]->id)); ?>');" disabled>
			            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_after[$j]->favor_count); ?>

			        </button>
					<?php else: ?>
						<button type="button" id="favor_btn" class="btn btn-default" onclick="postVote('1','<?php echo e(Crypt::encrypt($pictures_after[$j]->id)); ?>');">
			            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_after[$j]->favor_count); ?>

			        </button>
					<?php endif; ?>

					<?php if($history_after[$j]->recommended): ?>
						<button type="button" id="recommend_btn" class="btn btn-default" onclick="postVote('2','<?php echo e(Crypt::encrypt($pictures_after[$j]->id)); ?>');" disabled>
			            <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_after[$j]->recommend_count); ?>

			        </button>
					<?php else: ?>
						<button type="button"  id="recommend_btn" class="btn btn-default" onclick="postVote('2','<?php echo e(Crypt::encrypt($pictures_after[$j]->id)); ?>');">
			            <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>&nbsp;<?php echo e($pictures_after[$j]->recommend_count); ?>

			        </button>
					<?php endif; ?>
			    </div>
				</div>
				</div>
				<div class="wrap-user-information col-md-4 comment_section">
				<div class="picInfo-wrapp">
					<div class="media">
					  <div class="media-left">
					    <a href="#">
					      <img src="<?php echo e(url('/img/profile-image.jpg')); ?>" alt="" class="media-object img-circle uploader-profile-image">
					    </a>
					  </div>
					  <div class="media-body">
					    <h4 class="media-heading">
							<a class ="author" href="<?php echo e(url('/people/'.$pictures_after[$j]->user->user)); ?>"><?php echo e($pictures_after[$j]->user->user); ?></a>
							<ul>
								<?php if($followlist_after[$j] > 0): ?>
								<li>
									<?php if($followlist_after[$j]==0): ?>
										<a href="<?php echo e(url('/follow/'.$pictures_before[$j]->user->user)); ?>">
										<!-- follow -->
										</a>
									<?php else: ?>
										<a href="<?php echo e(url('/unfollow/'.$pictures_before[$j]->user->user)); ?>">
										unfollow
										</a>
									<?php endif; ?>
								</li>
								<?php endif; ?>
							</ul>
					    </h4>
					    <div class="pic_comment no-padding"> <?php echo e($pictures_after[$j]->comment); ?></div>
					    
					  </div>
					</div>
		         

		        </div>	
				</div>
			</div>
			
			</div>
<?php endfor; ?>

<!-- end of pictures after -->

			<?php /* <!-- <button type="button" class="btn btn-primary btn-loadbefore"> <?php if(count($pictures_before)==0): ?><?php echo e("Load More"); ?><?php else: ?><?php echo e('Load Before'); ?> <?php endif; ?>  </button>  --> */ ?>
			<?php /* <!-- <button type="button" class="btn btn-primary btn-loadafter"><?php if(count($pictures_after)==0): ?><?php echo e("Load More"); ?><?php else: ?><?php echo e('Load After'); ?> <?php endif; ?> </button> 	 --> */ ?>
			
	</div>


   
	

</div>

	<!-- <div id='timelime-right' style="height:770px;"> -->
		<!-- <div id="moving-point"></div> -->
	 <?php /* <?php for($i=0;$i<$num_of_photos;$i++): ?> */ ?>
	    <?php /* <div id='time-point' style="top:<?php echo e(((770/$num_of_photos)*$i+20)."px;"); ?>"></div> */ ?>
	 <?php /* <?php endfor; ?> */ ?>
	<!-- </div> -->

</div> <!-- end of timeline display -->


<script>
	
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/picture_blade.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>