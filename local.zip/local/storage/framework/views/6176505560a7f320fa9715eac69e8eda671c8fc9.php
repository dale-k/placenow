<!DOCTYPE html>
<html>
    <head>

		<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">
    	<script type="text/javascript" href="<?php echo e(URL::asset('js/bootstrap.js')); ?>"></script>
    	
    	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


    	<?php echo $__env->yieldContent('style'); ?>

    	<?php echo $__env->yieldContent('script'); ?>

		<?php echo $__env->yieldContent('content'); ?>

		<?php echo $__env->make('layouts.bottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


