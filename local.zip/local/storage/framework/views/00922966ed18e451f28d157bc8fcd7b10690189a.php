<!DOCTYPE html>
<html>
    <head>

		<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">