   

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('js/main.js')); ?>"></script>   
<?php $__env->stopSection(); ?>     

<?php $__env->startSection('content'); ?>

    </head>
    <body>
        <div class="container-fluid">

            <?php echo $__env->make('layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="jumbotron">
              <div class="container">
                <!--
                <h1>Hello, world!</h1>
                <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
                <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more »</a></p>
            -->
              </div>
            </div>

            
        
        </div>
        <div id="map"></div>

        <div id="list_control">
          <ul id="map_list">
               <p>Places Around You</p>
          </ul>
        </div>
        
        <div id="user_input">
            
            <form>
              <div class="form-group">
                <label for="exampleInputFile">Upload Your Photo</label>
                <input type="file" id="upload_photo" accept="image/*">
              </div>
              <div class="form-group">
                <textarea class="form-control" rows="2" placeholder="Leave Comment Here" id="user_comment"></textarea>
              </div>
              <button type="submit" class="btn btn-default">Submit</button>
            </form>

        </div>

        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDIgTQnz-ogU8mW_AidCUlYomtlrCDxUGQ&libraries=places&callback=initMap" async defer></script>

        

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>