<?php $__env->startSection('title','Tag - #'.$select_tag['tag']); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/tag.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
<style>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.tag_navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container-fluid wrap-content">
<div class="right-user-section col-md-3">
    <div class="col-md-4"></div>
    <div class="title-user col-md-8"> Popuplar User</div>
    <div class="col-md-4"></div>
    <div class="col-md-8 popular-user-wrapper ">
      
      <div class="user-info col-md-12">
        <div class="user-profile-img col-md-4">
        <img class="img-circle user-img img-responsive" src="<?php echo e(url('/img/profile-image.jpg')); ?>"/>
        </div>
        <div class="user-info-section col-md-8 no-padding">
          <div class="user-name col-md-8 no-padding"> Ritchie </div>
          <div class="user-follow-function col-md-4 no-padding"> Follow </div>
          <div class="following-count col-md-12 no-padding">Following:</div>
          <div class="follower-count col-md-12 no-padding">Follower:</div>
          <div class="post-count col-md-12 no-padding">Post:</div>
        </div>
      </div>
    </div>

</div>
<div class="middle-img-section col-md-6">	
		<div class="col-md-12 wrap-image">

			<div class="row img-container grid">
      <div class="col-xs-4 col-sm-6 col-md-4 grid-sizer"></div>
			  <?php foreach( $tag_pictures as $tp ): ?>
        <div class="popular-img-wrap col-md-4 col-xs-4 grid-item">

          <div class="img-place col-md-12 col-xs-12">
              <div>
                <div class="shine-text-place">&nbsp;&nbsp;
                  <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
                  &nbsp;   <a href="#" class="img-place-show" data-toggle="tooltip" title="<?php echo e($tp->place->city); ?>"><?php echo e($tp->place->location); ?>&nbsp;&nbsp;</a>
                </div>
              </div>
          </div>
          
          <a href="<?php echo e(url('/photo/'.$tp->id)); ?>">
            <img class='img-responsive' alt="" src="<?php echo e(url($tp->pic_location)); ?>">
          </a>
          
          <div class="img-info col-md-12 col-xs-12">
            <div class="img-author-time"> 
              <div class="shine-text-time">
                &nbsp;&nbsp;by&nbsp;
                <a><?php echo e($tp->user->user); ?></a>&nbsp;,&nbsp;
                    <span class="glyphicon glyphicon-time" aria-hidden="true"></span>
                    &nbsp;<?php echo e(trimCreatedAt($tp->created_at)); ?>&nbsp;&nbsp;
              </div>    
            </div>
          </div>
            <div class="tag-list col-md-12 col-xs-12">
              <?php foreach($tp->tag as $tag): ?>
              <a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;
              <?php endforeach; ?>
            </div>
            
        </div>
		    <?php endforeach; ?>	
		    </div>

		</div>    
</div>
</div>


<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/tag.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>