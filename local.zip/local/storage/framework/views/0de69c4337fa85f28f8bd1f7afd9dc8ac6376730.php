<?php $__env->startSection('title','Tag - #'.$select_tag['tag'].' - More'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/tag.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
<style>
.cover-all{
	padding:0px;	

}
.img-layer{
	position: absolute;
	top:0px;
	left:0px;
	width:100%;
	height:100%;

}

.img-tag{
	position: absolute;
	top:35%;
	left:0px;
	width:100%;
	font-size: 25px;
	text-align: center;
	color:white;
	z-index: 10;
}
.img-layer{
	background-color: #000;
	opacity: 0.6;
	z-index: 5;
}

</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tag-type',' - More'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.tag_navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">


	<div class="row wrap-content">
		
  	<div class="col-md-2" style="height:1px;"></div>
		<div class="col-md-8 wrap-image">

			<div class="img-container">
			<?php for( $i=0 ; $i<count($tags_more[0]);$i++): ?>
				
				<?php if(($i%3)==0): ?>
				<div class="row">
				<?php endif; ?>

				<div class="popular-img-wrap col-md-4 col-xs-12">
					
					<span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;<?php echo e(trimCreatedAt($toptags_pictures[$i]->created_at)); ?>

					<div class="cover-all col-md-12 col-xs-12">
					
					<img class='img-responsive' alt="" src="<?php echo e(url($toptags_pictures[$i]->pic_location)); ?>">
					<div class="img-layer"></div>
					<a href='<?php echo e(url('/tag/'.$tags_more[0][$i]->type)); ?>'><div class="img-tag ">#<?php echo e($tags_more[0][$i]->type); ?></div></a>
					
					</div>
				</div>
				
				<?php if(($i%3)==2): ?>
				</div>
				<?php endif; ?>
			
			<?php endfor; ?>

			</div>

		</div>    
	</div>

</div>



<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/tag.js')); ?>"></script>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>