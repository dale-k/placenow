   

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>

    </head>
    <body>
        <div class="container-fluid">

            <?php echo $__env->make('layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="jumbotron">
              <div class="container">
                <!--
                <h1>Hello, world!</h1>
                <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
                <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more »</a></p>
            -->
              </div>
            </div>

           
        <div id="map"></div>

        <div class="dropdown">

          <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Places Around You
            <span class="caret"></span>
          </button>

          <ul class="dropdown-menu" id="map_list" aria-labelledby="dropdownMenu1"></ul>

        </div>
        
       




<div id="user_form">
            
            <form id="inputs" method="POST" action="/post">
              <div class="form-group">
                <label for="exampleInputFile">Upload Your Photo</label>
                <input name ="pic_loc" type="file" id="upload_photo" accept="image/*">
              </div>
              <div class="form-group">
                <textarea name="comment" class="form-control" rows="2" placeholder="Leave Comment Here" id="user_comment"></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
              <input name="user" type="hidden" id="username" value="Ritchie"/>
              <input name="lat" type="hidden" id="user_lat" value="Ritchie"/>
              <input name="lng" type="hidden" id="user_lng" value="Ritchie"/>
              <input name="city" type="hidden" id="user_city" value="Ritchie"/>
              <input name="location" type="hidden" id="user_location" value="Ritchie"/>
            </form>

        </div>

        
        </div>

         

        
        <!-- <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDIgTQnz-ogU8mW_AidCUlYomtlrCDxUGQ&callback=loadCity"></script> -->



        

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('js/main.js')); ?>"></script>   
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDIgTQnz-ogU8mW_AidCUlYomtlrCDxUGQ&libraries=places&callback=initMap" async defer></script>
<?php $__env->stopSection(); ?>   




<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>