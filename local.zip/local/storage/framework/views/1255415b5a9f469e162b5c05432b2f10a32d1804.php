<?php $__env->startSection('title','Place Now - welcome'); ?>

<?php $__env->startSection('style'); ?>
  <?php /* <link href='https://fonts.googleapis.com/css?family=PT+Sans:700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Berkshire+Swash' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Permanent+Marker' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Vollkorn' rel='stylesheet' type='text/css'> */ ?>
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/welcome2.blade.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<div class="container wrap-margin">

  <div class="row padding-remove">

    <?php /* <div class="col-xs-12 col-sm-6 col-md-3 grid-sizer"></div> */ ?>

    

    

    <?php if(count($most_popular)): ?>

    <div class="col-xs-12 col-sm-6 col-md-6 wrap-most-popular padding-around">

      <a href="<?php echo e(url('photo/'.$most_popular[0]->id)); ?>" class="wrap-img mmp-1 block-border-radius">
        <img class="img-responsive" alt="" src="<?php echo e($most_popular[0]->pic_location); ?>">
      </a>

      <div class="wrap-mmp-content-1">
        
        <?php if( $most_popular[0]->title != '' ): ?>
          <div class="mmp-content-1">
            <h3><?php echo e($most_popular[0]->title); ?></h3>
          </div>
        <?php elseif( $most_popular[0]['comment'] != '' ): ?>
          <div class="mmp-content-1">
            <p><?php echo e($most_popular[0]['comment']); ?></p>
          </div>
        <?php elseif( count( $most_popular[0]->tag ) != 0 ): ?>
          <div class="mmp-content-1">
            <?php foreach( $most_popular[0]->tag as $mp ): ?>
              <a href="" class="comment-tag">#<?php echo e($mp->type); ?></a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div class="mmp-posted-by mmpp-1">

          <a href="<?php echo e(url('place/'.$most_popular[0]->place->id)); ?>" class="mmp-location mmpl-1">  
            @ <?php echo e($most_popular[0]->place->location); ?> . 
          </a>

          <a href="url('use/'.$most_popular[0]->user->user ) }}">
            By <?php echo e($most_popular[0]->user->user); ?>, 
            <?php echo e(trimCreatedAt($most_popular[0]->created_at)); ?>

          </a>

        </div>

      </div>

    </div>

    <?php endif; ?>

    <?php if(count($most_popular) > 1): ?>
    <div class="col-xs-12 col-sm-6 col-md-3 padding-remove">
    <?php for($i = 1; $i < 2; $i++): ?>

      <div class="col-xs-12 col-sm-6 col-md-12 wrap-most-popular padding-around">

        <a href="<?php echo e(url('photo/'.$most_popular[$i]->id)); ?>" class="wrap-img mmp-2 block-border-radius">
          <img class="img-responsive" alt="" src="<?php echo e($most_popular[$i]->pic_location); ?>">
        </a>

        <div class="wrap-mmp-content-2">
          
          <?php if( $most_popular[$i]->title != '' ): ?>
            <div class="mmp-content-2">
              <h3><?php echo e($most_popular[$i]->title); ?></h3>
            </div>
          <?php elseif( $most_popular[$i]['comment'] != '' ): ?>
            <div class="mmp-content-2">
              <p><?php echo e($most_popular[$i]['comment']); ?></p>
            </div>
          <?php elseif( count( $most_popular[$i]->tag ) != 0 ): ?>
            <div class="mmp-content-2">
              <?php foreach( $most_popular[$i]->tag as $mp ): ?>
                <a href="" class="comment-tag">#<?php echo e($mp->type); ?></a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <div class="mmp-posted-by mmpp-2">

            <a href="<?php echo e(url('place/'.$most_popular[$i]->place->id)); ?>" class="mmp-location mmpl-2">  
              @ <?php echo e($most_popular[$i]->place->location); ?> . 
            </a>

            <a href="url('use/'.$most_popular[$i]->user->user ) }}">
              By <?php echo e($most_popular[$i]->user->user); ?>, 
              <?php echo e(trimCreatedAt($most_popular[$i]->created_at)); ?>

            </a>

          </div>

        </div>

      </div>

    <?php endfor; ?>
    </div>
    <?php endif; ?>

    <?php if(count($most_popular) > 3 ): ?>
        <div class="col-xs-12 col-sm-6 col-md-3 padding-remove">
    <?php for($i = 2; $i < 4; $i++): ?>

      <div class="col-xs-12 col-sm-6 col-md-12 wrap-most-popular padding-around">

        <a href="<?php echo e(url('photo/'.$most_popular[$i]->id)); ?>" class="wrap-img mmp-3 block-border-radius">
          <img class="img-responsive" alt="" src="<?php echo e($most_popular[$i]->pic_location); ?>">
        </a>

        <div class="wrap-mmp-content-2">
          
          <?php if( $most_popular[$i]->title != '' ): ?>
            <div class="mmp-content-2">
              <h3><?php echo e($most_popular[$i]->title); ?></h3>
            </div>
          <?php elseif( $most_popular[$i]['comment'] != '' ): ?>
            <div class="mmp-content-2">
              <p><?php echo e($most_popular[$i]['comment']); ?></p>
            </div>
          <?php elseif( count( $most_popular[$i]->tag ) != 0 ): ?>
            <div class="mmp-content-2">
              <?php foreach( $most_popular[$i]->tag as $mp ): ?>
                <a href="" class="comment-tag">#<?php echo e($mp->type); ?></a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <div class="mmp-posted-by mmpp-2">

            <a href="<?php echo e(url('place/'.$most_popular[$i]->place->id)); ?>" class="mmp-location mmpl-2">  
              @ <?php echo e($most_popular[$i]->place->location); ?> . 
            </a>

            <a href="url('use/'.$most_popular[$i]->user->user ) }}">
              By <?php echo e($most_popular[$i]->user->user); ?>, 
              <?php echo e(trimCreatedAt($most_popular[$i]->created_at)); ?>

            </a>

          </div>

        </div>

      </div>

    <?php endfor; ?>
    </div>
    <?php endif; ?>

  </div>
</div>



<div class="container wrap-popular-place-container">

  <div class="row padding-remove">

    <!-- popular places -->
    <?php if(count($popular_place)): ?>
    <div class="col-xs-6 col-sm-12 col-md-3 wrap-popular-places-title padding-around">


      <h4 class="mpp-title block-border-radius">
        Popular Places
      </h4>


    </div>

    <?php for( $i = 0; $i < count($popular_place); $i++ ): ?>
    <div class="col-xs-6 col-sm-12 col-md-3 wrap-popular-places padding-around">

      <a href="<?php echo e(url('place/'.$popular_place[$i]->place->location )); ?>" class="wrap-img block-border-radius">

        <img class="img-responsive" alt="" src="<?php echo e($popular_place[$i]->pic_location); ?>">

        <h4 class="mpp-place">
          &nbsp;
          <?php echo e($popular_place[$i]->place->location); ?>

        </h4>

      </a>

    </div>
    <?php endfor; ?>

    <?php endif; ?>
    <!-- End - popular places -->




    



  </div><!-- end of first row -->

</div>


<!-- start container -->
<div class="container wrap-popular-tag-container">
  <div class="row padding-remove">

    <!-- Popular Tag -->
    <?php for( $pt = 0; $pt < count($popular_tag); $pt++ ): ?>
    <div class="col-xs-12 col-sm-6 col-md-3 wrap-popular-tags padding-remove">

      <div class="pt-title">
        Tag
      </div>

      <a class="pt-tag block-border-radius" href="<?php echo e(url('tag/'.$popular_tag[$pt]->type)); ?>">
        #<?php echo e($popular_tag[$pt]->type); ?>

      </a>

      <div class="pt-bt">
        <?php echo e($popular_tag[$pt]->type_count); ?> posts
      </div>

    </div>
    <?php endfor; ?>

  </div>
</div>
<!-- end container -->

<!-- start container -->
<div class="container wrap-popular-question-container">
  <div class="row padding-remove">

    <!-- popular Question -->
    <?php for($pq = 0; $pq < count($popularQuestion); $pq++): ?>

    <div class="col-xs-12 col-sm-6 col-md-3 grid-item wrap-popular-question padding-remove">
      
      <div class="pq-title">
        Ask
      </div>

      <a href="<?php echo e(url('ask/answers/'.$popularQuestion[0]->question)); ?>" class="popular-question block-border-radius">
        <h4 class="pq-question"><?php echo e($popularQuestion[$pq]->question); ?></h4>
      </a>

      <div class="pq-btn">
        <div class="pq-asked-by">
          Asked By 
          <a><?php echo e($popularQuestion[$pq]->user->user); ?></a>, 
          <?php echo e(trimCreatedAt($popularQuestion[$pq]->created_at)); ?>

        </div>
      </div>

    </div>

    <?php endfor; ?>
    <!-- End - popular Question -->

  </div>
</div>
<!-- end container -->


<!-- start container -->
<div class="container wrap-most-popular-container">

  <div class="row grid padding-remove">

    <div class="col-xs-12 col-sm-6 col-md-4 grid-sizer"></div>

      <?php if(count($most_popular) > 1): ?>

      <?php for($i = 2; $i < count($most_popular); $i++): ?>

      <div class="col-xs-12 col-sm-6 col-md-4 grid-item wrap-most-popular padding-around">

        <a href="<?php echo e(url('photo/'.$most_popular[$i]->id)); ?>" class="wrap-img mmp-3 block-border-radius">
          <img class="img-responsive" alt="" src="<?php echo e($most_popular[$i]->pic_location); ?>">
        </a>

        <div class="wrap-mmp-content-2">
          
          <?php if( $most_popular[$i]->title != '' ): ?>
            <div class="mmp-content-2">
              <h3><?php echo e($most_popular[$i]->title); ?></h3>
            </div>
          <?php elseif( $most_popular[$i]['comment'] != '' ): ?>
            <div class="mmp-content-2">
              <p><?php echo e($most_popular[$i]['comment']); ?></p>
            </div>
          <?php elseif( count( $most_popular[$i]->tag ) != 0 ): ?>
            <div class="mmp-content-2">
              <?php foreach( $most_popular[$i]->tag as $mp ): ?>
                <a href="" class="comment-tag">#<?php echo e($mp->type); ?></a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <div class="mmp-posted-by mmpp-2">

            <a href="<?php echo e(url('place/'.$most_popular[$i]->place->id)); ?>" class="mmp-location mmpl-2">  
              @ <?php echo e($most_popular[$i]->place->location); ?>

            </a>
   
            By 

            <a href="url('use/'.$most_popular[$i]->user->user ) }}">
              <?php echo e($most_popular[$i]->user->user); ?>

            </a>, 
            <?php echo e(trimCreatedAt($most_popular[$i]->created_at)); ?>


          </div>

        </div>

      </div>

      <?php if( $i%8 == 0): ?>

        <!-- Popular Tag -->
        <?php /* <div class="col-xs-12 col-sm-6 col-md-4 grid-item wrap-popular-tags padding-remove">

          <div class="pt-title">
            Popular Tag
          </div>

          <a class="pt-tag block-border-radius" href="<?php echo e(url('tag/'.$popular_tag[$j]->type)); ?>">
            #<?php echo e($popular_tag[$j]->type); ?>

          </a>

          <div class="pt-bt">
            <?php echo e($popular_tag[$j]->type_count); ?> posts
          </div>

            <input type="hidden" content="<?php echo e($popular_tag[$j++]); ?>">
        </div> */ ?>

      <?php endif; ?>

      <?php endfor; ?>

      <?php endif; ?>

  </div>

</div>
<!-- end container -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>