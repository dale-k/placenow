<?php $__env->startSection('title','Place Now - welcome'); ?>

<?php $__env->startSection('content'); ?>

<?php foreach($email_list as $i): ?>
	<?php echo e($i->email); ?>

<?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>