<?php $__env->startSection('title','Place Now'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/place.blade.css')); ?>">
<style type="text/css">

.about-place-title {
	text-transform: capitalize;
}
.top a.brand {
  display: none;
  margin-top: 10px;
  margin-bottom: 10px;
  height: 30px;
  line-height: 30px;
  font-weight: 800;
  font-size: 25px;
}
a.small-brand {
  float: left;
  margin-left: 10px;
  margin-bottom: 10px;
  padding: 2px 0 10px 0;
  height: 30px;
  font-weight: 800;
  font-size: 25px;
  font-family: 'PT Sans Narrow', sans-serif;
  text-decoration: none;
}
.wrap-nav-row .wrap-nav {
  float: right;
}
.wrap-nav-row {
  background-color: #fff;
  border-top: 0px solid #333;
  border-bottom: 2px solid #333;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">

	<div class="row">

		<div class="col-md-12">
			<h2>Most View</h2>
		</div>

		<div class="col-md-12">
			<h2>Latest</h2>
		</div>
		<?php foreach($nearbyplace_picture as $np): ?>
		<div class="col-md-3 wrap-latest">
			<div class="latest-tags">
             	#uofa#tucson#az
            </div>
			<a href="<?php echo e(url('photo/'.$np->id)); ?>" class="wrap-latest-img">
        		<img class="img-responsive" alt="Responsive image" src="<?php echo e(url($np->pic_location)); ?>">
             </a>
             <div class="wrap-mile-time">
	             <div class="latest-how-far"> <?php echo e($np->distance); ?> </div>
	             <div class="latest-when"><?php echo e(trimCreatedAt($np->created_at)); ?></div>
	         </div>

		</div>
		<?php endforeach; ?>


	</div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>