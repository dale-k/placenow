<div class="container-fluid">
  
  <div class="row wrap-nav-row">
  <div class="brand-name"> <a class="brand" href="<?php echo e(url('/welcome')); ?>">What's Happening!</a> </div>
    <div class="wrap-nav">
      <ul class="nav nav-pills">
        <li role="presentation"><a href="<?php echo e(url('/welcome')); ?>">World</a></li>
        <li role="presentation"><a href="<?php echo e(url('/city/'.Auth::user()->getUserCity())); ?>"><?php echo e(Auth::user()->getUserCity()); ?></a></li>
        <li role="presentation"><a href="<?php echo e(url('nearby')); ?>">Nearby</a></li>
        <li role="presentation"><a href="<?php echo e(url('/tagtest')); ?>">Tags</a></li>
        <li><a href="/placenow/postmyphoto" class="nav-share-photo" role="button">SharePhoto</a></li>
        <li><a href="/placenow/chat" class="nav-join-chat" role="button">TalkToYourNeighbor</a></li>
        <li role="presentation"><a href="#">Search</a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
              Me<span class="caret"></span>
          </a>

          <ul class="dropdown-menu" role="menu">
              <li><a href=""><i class="fa fa-btn fa-sign-out"></i></a></li>
              <li><a href="<?php echo e(url('/profile')); ?>"><i class="fa fa-btn fa-sign-out"></i>Profile</a></li>
              <?php if(Auth::user()->email=='admin@admin.admin'): ?>
              <li><a href="<?php echo e(url('/management')); ?>"><i class="fa fa-btn fa-sign-out"></i>Management</a></li>
              <?php endif; ?> 
              <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
          </ul>
      </li>
      </ul>
    </div>
  </div>
</div>