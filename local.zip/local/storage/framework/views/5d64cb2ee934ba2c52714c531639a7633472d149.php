<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/css/jasny-bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/uploadmyphoto.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','Place Now - Post'); ?>



<?php $__env->startSection('content'); ?>
<?php $__env->startSection('top'); ?>
<?php $__env->stopSection(true); ?>
	<div class="container">
		<div class="row">
			<div class="page-header">
			  <h1 id="pageHeader1">Post My Photo</h1>
			</div>
			<div id="map"></div>
			<div class="panel panel-primary">
				<div class="panel-heading"> <h2 class="panel-title" id="panelTitle">Panel title</h2> </div>
				<div class="panel-body" id="panelBody">

					<div class="progress" id="progressBar_wrap">
					  <div class="progress-bar progress-bar-striped active" id="progressBar" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
					    <span class="sr-only">45% Complete</span>
					  </div>
					</div>

				    <ul class="list-group" id="listGroup"></ul>

					<button type="button" class="btn btn-danger btn-lg active" onclick="youcantfind();">You can't find ?</button>
					<button type="button" class="btn btn-default btn-lg active">Cancel</button>

				</div>
			</div>
		</div>
		
		
	</div><!-- container -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('buttom'); ?>
<?php $__env->stopSection(true); ?>



<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('js/uploadmyphoto.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDIgTQnz-ogU8mW_AidCUlYomtlrCDxUGQ&libraries=places&callback=initMap" async defer></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>