<?php $__env->startSection('title','People'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/people.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<?php if(strtolower(Auth::user()->user) == strtolower($username['username'])): ?>
		<div class="col-md-12">
			<?php echo e($username['username']); ?>

		</div>
		<?php else: ?>
				
		<?php endif; ?>
		<div class="col-md-12 wrap-user-information">
			<h1><?php echo e($username['username']); ?></h1>
			<ul>
					<?php if($username['same'] == 0): ?>
					<li>
						<?php if($username['record']==0): ?>
							<a href="<?php echo e(url('/follow/'.$username['username'])); ?>">
								follow
							</a>
						<?php else: ?>
							<a href="<?php echo e(url('/unfollow/'.$username['username'])); ?>">
								unfollow
							</a>
						<?php endif; ?>
					</li>
					<?php endif; ?>
				<li>
					<?php echo e($username['post_count']); ?> posts
				</li>
				<li>
					<a data-toggle="modal" data-target="#followers_modal">
						<?php echo e($username['follower_count']); ?> followers
					</a>
				</li>
				<li>
					<a data-toggle="modal" data-target="#followings_modal">
						<?php echo e($username['following_count']); ?> followings
					</a>
				</li>	
			</ul>	
		</div>
		<div class="col-md-12 wrap-post">
			<?php foreach($pictures as $i): ?>
				<img src="<?php echo e($i->pic_location); ?>">
			<?php endforeach; ?>
		</div>

	</div>

	<!-- Modal for follower list -->
	<div class="modal fade" id="followers_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="myModalLabel">Followers</h4>
	      </div>
	      <div class="modal-body">
	      	<ul>
	      		<?php foreach($follower_list as $fw_list): ?>
	      			<li>
	      				<?php echo e($fw_list->user); ?>

	      			</li>
	      		<?php endforeach; ?>
	      	</ul>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	      </div>
	    </div>
	  </div>
	</div>

	<!-- Modal for following list -->
	<div class="modal fade" id="followings_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="myModalLabel">Followings</h4>
	      </div>
	      <div class="modal-body">
	      	<ul>
	      		<?php foreach($following_list as $fwing_list): ?>
	      			<li>
	      				<?php echo e($fwing_list->user); ?>

	      			</li>
	      		<?php endforeach; ?>
	      	</ul>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	      </div>
	    </div>
	  </div>
	</div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>