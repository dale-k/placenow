<?php $__env->startSection('title','Place Now'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/nearby.blade.css')); ?>">
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container-fluid wrap-margin">

  <div class="row">

  </div>

	<div class="row grid">

    <div class="col-xs-12 col-sm-6 col-md-3 grid-sizer"></div>


		<?php foreach($nearbyplace_picture as $np): ?>
		<div class="col-xs-12 col-sm-6 col-md-3 wrap-nearby grid-item padding-around">

      <div class="nearby">

  			<a href="<?php echo e(url('photo/'.$np->id)); ?>" class="wrap-nearby-img">
      		<img class="img-responsive" alt="Responsive image" src="<?php echo e(url($np->pic_location)); ?>">
        </a>

        <div class="nearby-content">

          <a class="nearby-location" href="<?php echo e(url( 'place/'.$np->place->location )); ?>">
            <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
            <?php echo e($np->place->location); ?> ( <?php echo e(roundDistance($np->distance)); ?> )
          </a>

          <?php if( $np->title != '' ): ?>
            <h4><?php echo e($np->title); ?></h4>
          <?php endif; ?>

          <?php if( $np->comment != '' ): ?>
            <p><?php echo e($np->comment); ?></p>
          <?php endif; ?>

          <?php if(count($np->tag)>0): ?>
            <div class="wrap-tags">
            <?php foreach($np->tag as $tag): ?>
              <a href="">#<?php echo e($tag->type); ?></a>
            <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <div class="wrap-user-time">
            <div class="nearby-user">By <?php echo e($np->user->user); ?>,</div> 
            <div class="nearby-when"><?php echo e(trimCreatedAt($np->created_at)); ?></div>
          </div>
        </div>

  		</div>
    </div>
		<?php endforeach; ?>

	</div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/nearby.blade.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>