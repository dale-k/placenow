<!DOCTYPE html>
<html>
    <head>
    	<title><?php echo $__env->yieldContent('title'); ?></title>

    	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">
    	
    	<?php echo $__env->yieldContent('style'); ?>	
	
	</head>
	
	<body>
	
		<?php $__env->startSection('top'); ?>
		<?php echo $__env->make('layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>
		<?php echo $__env->yieldContent('content'); ?>	
		<?php $__env->startSection('bottom'); ?>
		<?php echo $__env->make('layouts.bottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>


	
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	
		<script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.js')); ?>"></script>
		
		<?php echo $__env->yieldContent('script'); ?>

	</body>

		

</html>	


