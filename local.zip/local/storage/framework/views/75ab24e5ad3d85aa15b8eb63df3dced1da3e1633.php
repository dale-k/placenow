<?php $__env->startSection('title','Place Now - tagtest'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/top_modified.css')); ?>">
<style type="text/css">
 

/*tag*/
.tag-content{
  margin-top:55px;
}
.row{
	margin-top: 5px;
}
.row-1{
  height:610px;
  margin-bottom:5px;
}
.box-wrap {
  padding:0px;
}
.big-img-wrap{
  padding-top:0px;
  padding-left: 0px;
  padding-bottom: 3px;
  padding-right:3px;
  overflow:hidden;
  height:303px;

}
.box-wrap > div{
  padding-top:0px;
  padding-left: 0px;
  padding-bottom: 3px;
  padding-right:3px;
  
}

.img-wrap a {
  position: relative;
  display:block;
  width:100%;
  height:150px !important;
  overflow: hidden;
}
.big-img-wrap a {
  position: relative;
  display:block;
  width:100%;
  height:303px !important;
  overflow: hidden;
}
.wrapped-img{
  position: relative;
}

.tag-overlay{
  position: absolute;
  bottom:0px;
  width:100%;
  height:30px;
  color: #333;
  background-color: #c3c3c3;
  z-index: 6;
  opacity: 0.5;
}
.tag-overlay>div{
  height: 30px;
  line-height: 30px;
  text-align: center;
  font-size: 20px;
  font-weight: 300;
  z-index: 10;
  color:black;
  opacity: 1;
}
.tag-move-up{
  
  float:left;
  z-index: 10;
}
hr{
  border-top: 1px solid #988e8e;
}
/*    Carousel      */
.carousel .item {
    /*height: 500px; OLD*/
    /*background-color: #777; OLD*/

    width:100%;
    height:inherit;
}
.carousel-inner > .item > img {
  /*position: absolute; OLD+WHY?*/
  /*top: 0; OLD+WHY?*/
  /*left: 0; OLD+WHY?*/

  min-width:100%;
  height:inherit;
}

.tag-list, .img-counts, .pic_counts{
  padding:0px;
}

.tag-list{
  font-size: 25px;
  padding-left:5px;

}

.tag-list a{
  background-color: #d6cfcf;
  margin-right:3px;
  padding-left: 3px;
  padding-right:3px;
  border-radius: 2px;
}
.bottom-part{
  background-color: #9fd7fb;
}
.latest-img-wrap , .popular-img-wrap{
  
  padding:15px;
  padding-top:20px;
}

.row-1-2{
  position: relative;
  margin-bottom:30px;
}

div.container-left, div.container-right{
  
  margin-top: 20px;
  padding:0px;
  
}
h1.center-title{
  margin:0;
  width:100%;
  text-align: center;
}
hr{
  margin:0;
  padding-top:20px;
  padding-bottom:20px;
}
img.display-img{
  border-radius: 3px;
}

/*img place and user , time */

div.img-place > div{
  font-size:15px;
  position: absolute;
  top:5px;
  left:0px;
  background-color:#ff4747;
  white-space:nowrap;
  overflow:hidden;
  width:30%;
}

/*#f9f6f6*/
div.img-author-time{
  position: absolute;
  bottom:5px;
  right:5px;
  background-color: #f9f6f6;
  border-radius: 5px;
  /*opacity: 0.6;*/
}
div.shine-text{
  color:white;

}
div.shine-text-place a, .glyphicon-map-marker{
  color:white !important;
  cursor:pointer;
}

div.shine-text-time a{
  color:black !important;
  cursor:pointer;
}



</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.top_new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid tag-content">

<div class="row row-1 ">
<div class="col-md-1"></div>
<div class="top-part col-md-10 col-xs-12">
    <div class="big-img-wrap col-md-6 carousel-1 slide col-xs-12">
      <div class="carousel-inner" role="listbox">
      <a id="link" class="item active" href="<?php echo e(url('/tag/'.$tags[0]->type)); ?>">
      <img class="wrapped-img" src="<?php echo e(url($tags[0]->TopPicture($tags[0]->type)->pic_location)); ?>">
      <div class="tag-overlay"><div><?php echo e($tags[0]->type); ?></div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#pokemonGo</div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#pokemon_rare</div></div>
      </a>
      </div>
    </div>
    <div class="box-wrap col-md-6 col-xs-12">
      <div class="img-wrap col-md-8 carousel-2 slide col-xs-8">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#sport</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#baseball</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#football</div></div>
        </a>
        </div>
      </div>

  		<div class="img-wrap col-md-4 carousel-3 slide col-xs-4">
        <div class="carousel-inner" role="listbox">
  			<a id="link" class="item  active" href="#">
  			<img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
  			<div class="tag-overlay"><div>#food</div></div>
  			</a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#restaurant</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#delicious</div></div>
        </a>
        </div>
  		</div>
  		
  		<div class="img-wrap col-md-4 carousel-4 slide col-xs-4">
  		  <div class="carousel-inner" role="listbox">
      	<a id="link" class="item  active" href="#">
  			<img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
  			<div class="tag-overlay"><div>#fun</div></div>
  			</a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#funny</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#interesting</div></div>
        </a>
        </div>
  		</div>

  		<div class="img-wrap col-md-8 carousel-5 slide col-xs-8">
        <div class="carousel-inner" role="listbox">
  			<a id="link" class="item  active" href="#">
  			<img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
  			<div class="tag-overlay"><div>#love</div></div>
  			</a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#relationship</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#happiness</div></div>
        </a>
        </div>
  		</div>
    </div>

                <!-- next line -->



    <div class="box-wrap col-md-6 hidden-xs">
  		<div class="img-wrap col-md-4 carousel-6 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#home</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#family</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#house</div></div>
        </a>
        </div>
  		</div>

  		<div class="img-wrap col-md-8 carousel-7 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#good</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#amazing</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#wonderful</div></div>
        </a>
        </div>
  		</div>

      <div class="img-wrap col-md-8 tag-move-up carousel-8 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#cool</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#dangerous</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-09--12-07-35am.jpg">
        <div class="tag-overlay"><div>#fake</div></div>
        </a>
        </div>
      </div>

      <div class="img-wrap col-md-4 tag-move-up carousel-9 slide">
        <div class="carousel-inner" role="listbox">
        <a id="link" class="item  active" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#newopening</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#closed</div></div>
        </a>
        <a id="link" class="item" href="#">
        <img class="wrapped-img" src="img/Tucson2016-07-11--02-47-17am.jpg">
        <div class="tag-overlay"><div>#shutdown</div></div>
        </a>
        </div>
      </div>

    </div>

    <div class="big-img-wrap col-md-6 last-big-img carousel-10 slide hidden-xs">
      <div class="carousel-inner" role="listbox">
      <a id="link" class="item  active" href="<?php echo e(url('/tag/'.$tags[1]->type)); ?>">
      <img class="wrapped-img" src="<?php echo e(url($tags[1]->TopPicture($tags[1]->type)->pic_location)); ?>">
      <div class="tag-overlay"><div><?php echo e($tags[1]->type); ?></div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#something</div></div>
      </a>
      <a id="link" class="item" href="#">
      <img class="wrapped-img" src="img/Tucson2016-06-29--04-54-40am.jpg">
      <div class="tag-overlay"><div>#somethingelse</div></div>
      </a>
      </div>
    </div>

</div>
</div>

<div class="row bottom-part">
     <div class="container-left col-md-6 col-xs-12">
      <h1 class="center-title">latest</h1>
      <hr class="divider">
      <div class="latest-img-container grid">
      <div class="grid-sizer col-md-6 col-xs-6"></div>
        <?php foreach($latest_pictures as $lpicture): ?>
        <div class="latest-img-wrap col-md-6 col-xs-6 grid-item">

          <div class="tag-list col-md-12 col-xs-12">
              <?php foreach($lpicture->tag as $tag): ?>
              <a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;
              <?php endforeach; ?>
            </div>
          <div class="img-place col-md-12 col-xs-12">
              <div>
                <div class="shine-text-place">&nbsp;&nbsp;
                  <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
                  &nbsp;   <a href="#" class="img-place-show" data-toggle="tooltip" data-placement="bottom" data-delay='{"show":"0", "hide":"100"}' title="@ <?php echo e($lpicture->place->location); ?>"><?php echo e($lpicture->place->city); ?>&nbsp;&nbsp;</a>
                </div>
              </div>
          </div>
          
          <a href="<?php echo e(url('/photo/'.$lpicture->id)); ?>">
          <img class='img-responsive display-img' alt="" src="<?php echo e($lpicture->pic_location); ?>"></a>
            <div class="img-info col-md-12 col-xs-12">
            <div class="img-author-time"> 
              <div class="shine-text-time">
                &nbsp;&nbsp;by&nbsp;
                <a><?php echo e($lpicture->user->user); ?></a>&nbsp;,&nbsp;
                    <span class="glyphicon glyphicon-time" aria-hidden="true"></span>
                    &nbsp;<?php echo e(trimCreatedAt($lpicture->created_at)); ?>&nbsp;&nbsp;
              </div>    
            </div>
          </div>

        </div>
        <?php endforeach; ?>
      </div>
    </div>



    <div class="container-right col-md-6 col-xs-12">
      <h1 class="center-title">popular</h1>
      <hr class="divider">
      <div class="popular-img-container grid">
      <div class="grid-sizer col-md-6 col-xs-6"></div>
        <?php foreach($popular_pictures as $ppicture): ?>
        <div class="popular-img-wrap col-md-6 col-xs-6 grid-item">

        <div class="tag-list col-md-12 col-xs-12">
              <?php foreach($ppicture->tag as $tag): ?>
              <a href="<?php echo e(url('tag/'.$tag->type)); ?>"> #<?php echo e($tag->type); ?> </a>&nbsp;
              <?php endforeach; ?>
            </div>
          <div class="img-place col-md-12 col-xs-12">
              <div>
                <div class="shine-text-place">&nbsp;&nbsp;
                  <span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
                  &nbsp;   <a href="#" class="img-place-show" data-toggle="tooltip" data-placement="bottom" data-delay='{"show":"0", "hide":"100"}' title="@ <?php echo e($lpicture->place->location); ?>"><?php echo e($lpicture->place->city); ?>&nbsp;&nbsp;</a>
                </div>
              </div>
          </div>
          
          <a href="<?php echo e(url('/photo/'.$ppicture->id)); ?>">
          <img class='img-responsive display-img' alt="" src="<?php echo e($ppicture->pic_location); ?>"></a>
            <div class="img-info col-md-12 col-xs-12">
            <div class="img-author-time"> 
              <div class="shine-text-time">
                &nbsp;&nbsp;by&nbsp;
                <a><?php echo e($ppicture->user->user); ?></a>&nbsp;,&nbsp;
                    <span class="glyphicon glyphicon-time" aria-hidden="true"></span>
                    &nbsp;<?php echo e(trimCreatedAt($ppicture->created_at)); ?>&nbsp;&nbsp;
              </div>    
            </div>
          </div>

        </div>
        <?php endforeach; ?>
      </div>
    </div>

   
    
    

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>


<script>

$(document).ready(function(){


 $('.carousel-1').carousel({ interval: 10000});// big
 $('.carousel-2').carousel({ interval: 7000 });
 $('.carousel-3').carousel({ interval: 4500 });// small
 $('.carousel-4').carousel({ interval: 5500 });// small
 $('.carousel-5').carousel({ interval: 4500 });
 $('.carousel-6').carousel({ interval: 6500 });// small
 $('.carousel-7').carousel({ interval: 8000 });
 $('.carousel-8').carousel({ interval: 9000 });
 $('.carousel-9').carousel({ interval: 3500 });// small
 $('.carousel-10').carousel({ interval: 9500 }); // big

$("img").width( $("img").parent().width());
$("img").height("inherit");


    var $grid = $('.grid').masonry({
      itemSelector: '.grid-item',
      columnWidth: '.grid-sizer',
      percentPosition: true
    });
  $grid.imagesLoaded().progress( function() {
    $grid.masonry('layout');
  });



});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>