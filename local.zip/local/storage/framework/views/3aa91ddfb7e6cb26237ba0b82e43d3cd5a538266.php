<?php if(Auth::user()->email=='admin@admin.admin'): ?>


<?php $__env->startSection('title','Place Now Management'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
<!-- 4 section   picture  user   place   chat -->
	<div class="row">
		<div class="container-inline" id="show_picture">
			Total Photo upload :<?php echo e($pictures->count()); ?>

			<!-- show list of picture  -->

		</div>
		<div class="container-inline" id="show_user">
			Total User registered :<?php echo e($users->count()); ?>

		</div>
	</div>
	<div class="row">
		<div class="container-inline" id="show_place">
			Place recorded : <?php echo e($places->count()); ?>


		</div>
		
	</div>
	<div class="row">
		<div class="container-inline" id="show_chatroom">
			Chatroom avaiable : <?php echo e($chatrooms->count()); ?>


		</div>
	</div>
	<div class="row">
		<div class="container-inline" id="show_chat">
				
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php else: ?>
	<script>
        window.location = "/";
    </script>
<?php endif; ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>