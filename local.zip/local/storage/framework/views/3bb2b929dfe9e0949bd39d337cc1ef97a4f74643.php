<?php $__env->startSection('title','Place Now'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/welcom_carousel.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="carousel-container">
            <!-- Indicators -->
    <div id="carousel_title">Top Cities</div>
            
    <div id="carousel-1" class="carousel slide" data-ride="carousel">
          
          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <img id="img_car" src="img/tucsoncity_1.jpg" alt="img1">
              <div class="carousel-caption"></div>
            </div>
            <div class="item">
              <img id="img_car" src="img/tucsoncity_2.png" alt="img2">
              <div class="carousel-caption"></div>
            </div>
            <div class="item">
              <img id="img_car" src="img/tucsoncity_3.jpg" alt="img3">
              <div class="carousel-caption"></div>
            </div>
          </div>

          <!-- Controls -->
          <a class="left carousel-control" href="#carousel-1" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#carousel-1" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
    </div>
    
    <div id="carousel_title">Top Location</div>

    <div id="carousel-2" class="carousel slide" data-ride="carousel">
          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <img id="img_car" src="img/tucsoncity_1.jpg" alt="img1">
              <div class="carousel-caption"></div>
            </div>
            <div class="item">
              <img id="img_car" src="img/tucsoncity_2.png" alt="img2">
              <div class="carousel-caption"></div>
            </div>
            <div class="item">
              <img id="img_car" src="img/tucsoncity_3.jpg" alt="img3">
              <div class="carousel-caption"></div>
            </div>
          </div>

          <!-- Controls -->
          <a class="left carousel-control" href="#carousel-2" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#carousel-2" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>